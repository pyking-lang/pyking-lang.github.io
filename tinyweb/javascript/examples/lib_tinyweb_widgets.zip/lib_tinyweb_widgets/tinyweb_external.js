// The JavaScript implementation of the names declared in
// tinyweb_external.pyk for node, where there is no page around the
// program. tinyweb_external_browser.js is the one web uses, and
// tinyweb_external_interpreter.js the one iweb, the playground and
// the notebook use.
//
// A program talks to its page in commands and the page answers in
// events (docs/libraries.md, "tinyweb"). Where they go:
//
//   - $PYKING_TINYWEB_LOG set: no page. Each command is a line in that
//     file, and once the top level has ended the events
//     $PYKING_TINYWEB_EVENTS lists are delivered -- how a program is
//     tested.
//   - otherwise `web_init(port)` serves the page, tinyweb_page.html and
//     tinyweb_page.js (copied into this file below), from node's own
//     http server on a worker thread of its own -- this same file, run
//     there (`serveOnWorker`): GET /commands is a stream of command
//     batches (server-sent events) and POST /events one event each,
//     delivered as it arrives -- after the top level, which runs to its
//     end before node looks at the events, or while `sdelay` waits --
//     and answered with `event_done` once what it caused has been sent.
//     The server is on a thread of its own so that it answers while the
//     program waits in `sdelay`, which blocks this one.
//   - neither: the first call says `web_init` is missing, and the
//     program ends with status 1.

import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  MessageChannel, Worker, isMainThread, parentPort, receiveMessageOnPort, workerData,
} from "node:worker_threads";

const LOG = process.env.PYKING_TINYWEB_LOG;
const EVENTS = process.env.PYKING_TINYWEB_EVENTS;
const HERE = path.dirname(fileURLToPath(import.meta.url));

// Every identifier given out so far.
const names = new Set();
let clock = 0;
// Whether an event has been delivered: until one is, the program is in
// its top level, whose sound a page connecting later still plays.
let delivered = false;
const buttons = new Map();
const sliders = new Map();
const checks = new Map();
const radios = new Map();
const choices = new Map();
const texts = new Map();
const mice = new Map();
const frames = [];
const keys = [];
const keyUps = [];
// The keys held down now, from the key events delivered so far.
const down = new Set();
let keysOn = false;
// Each canvas's pointer: the functions watching it, by kind, and where
// it was last seen.
const pointers = new Map();
const measures = new Map();
const bitmaps = new Map();
// The functions `watch` handed over, by element and kind, and what the
// page last reported, by name: an array of numbers or a text.
const watchers = new Map();
const reports = new Map();
let after = false;
let hub = null;
// tinyweb's `sdelay`: how many have been sent, and with no page, where
// the last one ended on the clock the events give.
let sdelays = 0;
let sdelayEnd = null;

// --- commands ---

const quote = (text) => JSON.stringify(text);

// A number with three digits after the point, as C's "%.3f" writes it:
// a number exactly halfway between two is rounded to the even one, where
// toFixed would round it up. Float -> String
function fixed3(x) {
  if (!Number.isFinite(x)) return String(x);
  const negative = x < 0 || Object.is(x, -0);
  const a = Math.abs(x);
  // Halfway exactly only where a is a multiple of 1/16 ending in 5 at
  // the fourth place, which a double holds exactly.
  if (Number.isInteger(a * 16) && a.toFixed(4).endsWith("5")) {
    const below = Math.floor(a * 1000);
    const even = below % 2 === 0 ? below : below + 1;
    return (negative ? "-" : "") + (even / 1000).toFixed(3);
  }
  return (negative ? "-" : "") + a.toFixed(3);
}

// A command as the one line every headless implementation writes.
function logLine(command) {
  const s = fixed3;
  const q = (x) => JSON.stringify(x);
  const c = command;
  const named = (id, text) => q(id) + (id === text ? "" : " " + q(text));
  switch (c.op) {
    case "canvas": return `canvas ${q(c.id)} ${c.width} ${c.height}`;
    case "clear": return `clear ${q(c.c)} ${c.color}`;
    case "shape":
      return `${c.kind} ${q(c.c)} ${typeof c.numbers === "string" ? c.numbers : c.numbers.map(s).join(" ")} ` +
        `${q(c.color)} ${q(c.outline)} ${s(c.width)} ${s(c.alpha)}`;
    case "text":
      return `text ${q(c.c)} ${s(c.x)} ${s(c.y)} ${q(c.color)} ${c.size} ${q(c.font)} ${c.align} ` +
        `${c.baseline} ${c.bold} ${q(c.outline)} ${s(c.outline_width)} ${s(c.alpha)} ${q(c.words)}`;
    case "measure": return `measure ${q(c.id)} ${c.size} ${q(c.font)} ${c.bold} ${q(c.words)}`;
    case "on_pointer": return `on_pointer ${q(c.c)}`;
    case "row": case "column": case "inside": return `${c.op} ${q(c.id)}`;
    case "bitmap":
      return `bitmap ${q(c.c)} ${q(c.id)} ${c.x} ${c.y} ${s(c.scale)} ${c.width} ${c.height} ` +
        `${c.rect.join(" ")} ${c.digest}`;
    case "state":
      return [c.kind, q(c.c)].concat(c.value === "" ? [] : [q(c.value)])
        .concat(c.numbers === "" ? [] : [c.numbers]).join(" ");
    case "image_load": return `load_image ${named(c.id, c.name)}`;
    case "image":
      return `image ${q(c.c)} ${q(c.picture)} ${c.x} ${c.y} ${c.width} ${c.height} ${s(c.alpha)}`;
    case "button": return `button ${named(c.id, c.title)}`;
    case "label": return `label ${named(c.id, c.text)}`;
    case "set_label": return `set_label ${q(c.id)} ${q(c.text)}`;
    case "slider": return `slider ${q(c.id)} ${c.low} ${c.high} ${c.value}`;
    case "checkbox": return `checkbox ${named(c.id, c.title)} ${c.checked}`;
    case "radio": return `radio ${named(c.id, c.title)} ${q(c.group)} ${c.chosen}`;
    case "choice": return `choice ${q(c.id)} ${c.chosen} ${q(c.options)}`;
    case "text_input": return `text_input ${named(c.id, c.placeholder)}`;
    case "number": return `number ${q(c.id)} ${c.low} ${c.high} ${c.value}`;
    case "set_checked": return `set_checked ${q(c.id)} ${c.checked}`;
    case "set_value": return `set_value ${q(c.id)} ${c.value}`;
    case "load": return `load ${named(c.id, c.name)}`;
    case "cmd":
      return `${c.kind} ${q(c.id)}${c.text === "" ? "" : " " + q(c.text)}` +
        `${c.numbers === "" ? "" : " " + c.numbers}`;
    case "on_mouse": return `on_mouse ${q(c.c)}`;
    case "style": return `style ${q(c.id)} ${c.kind} ${c.prop} ${q(c.value)}`;
    case "splash_text": return `splash_text ${q(c.text)}`;
    case "sdelay": return `sdelay ${fixed3(c.seconds)}`;
    default: return c.op;
  }
}

function writeLog(line) {
  fs.appendFileSync(LOG, line + "\n");
}

// What every function but `web_init` needs first: a log to write to,
// or a page served.
function ready() {
  if (LOG !== undefined) {
    if (!after) {
      after = true;
      setTimeout(afterProgram, 0);
    }
    return;
  }
  if (hub === null) {
    refuse("tinyweb: call tinyweb.web_init(port) before anything else, " +
      "or set PYKING_TINYWEB_LOG");
  }
}

// Ends the program with `message`, and with status 1.
function refuse(message) {
  fs.writeSync(2, message + "\n");
  process.exit(1);
}

function send(command) {
  ready();
  if (LOG !== undefined) {
    if (command.op !== "frame_done" && command.op !== "event_done") writeLog(logLine(command));
  } else {
    hub.send(command);
  }
}

// A new element's identifier: `name`, or `name` with the first number
// from 1 that makes it one nothing on the page has.
function fresh(name) {
  // An empty name would be the page's own identifier.
  if (name === "") name = "element";
  let found = name;
  for (let n = 1; names.has(found); n++) found = name + n;
  names.add(found);
  return found;
}

// --- the functions tinyweb_external.pyk declares ---

export function web_start(port) {
  if (LOG !== undefined || hub !== null) return;
  if (!(port >= 0 && port <= 65535)) {
    refuse(`tinyweb: cannot serve the page on port ${port}: a port is a number from 0 to 65535`);
  }
  hub = new Hub(port);
}

export function canvas(width, height) {
  ready();
  const id = fresh("canvas");
  send({ op: "canvas", id, width, height });
  return id;
}

export function fill_canvas(c, color) {
  send({ op: "clear", c, color });
}

export function draw_shape(c, kind, numbers, color, outline, width, alpha) {
  send({ op: "shape", c, kind, numbers, color, outline, width, alpha });
}

// A list of tuples as the one array of numbers the page reads.
// [[Float]] -> [Float]
function flat(items) {
  const numbers = [];
  for (const item of items) for (const x of item) numbers.push(x);
  return numbers;
}

export function draw_pairs(c, kind, items, color, outline, width, alpha) {
  draw_shape(c, kind, flat(items), color, outline, width, alpha);
}

export function draw_triples(c, kind, items, color, outline, width, alpha) {
  draw_shape(c, kind, flat(items), color, outline, width, alpha);
}

export function draw_quads(c, kind, items, color, outline, width, alpha) {
  draw_shape(c, kind, flat(items), color, outline, width, alpha);
}

export function draw_text(c, x, y, words, color, size, font, align, baseline, bold, outline,
  outlineWidth, alpha) {
  send({ op: "text", c, x, y, words, color, size, font, align, baseline, bold, outline,
    outline_width: outlineWidth, alpha });
}

export function measure(words, size, font, bold, answer) {
  ready();
  const id = fresh("measure");
  measures.set(id, answer);
  send({ op: "measure", id, words, size, font, bold });
}

export function watch_pointer(c, kind, f) {
  ready();
  if (!pointers.has(c)) {
    pointers.set(c, { press: [], release: [], move: [], drag: [], x: 0, y: 0, down: false });
    send({ op: "on_pointer", c });
  }
  const seen = pointers.get(c);
  if (Array.isArray(seen[kind])) seen[kind].push(f);
}

export function pointer(c, which) {
  ready();
  const seen = pointers.get(c);
  if (seen === undefined) return 0;
  if (which === "x") return seen.x;
  if (which === "y") return seen.y;
  return seen.down ? 1 : 0;
}

// --- bitmaps ---

// FNV-1a, 32 bits, of the bytes: what the log says of a bitmap's pixels.
function digest(bytes) {
  let h = 0x811c9dc5;
  for (let i = 0; i < bytes.length; i++) h = Math.imul(h ^ bytes[i], 16777619) >>> 0;
  return h.toString(16).padStart(8, "0");
}

export function make_bitmap(width, height, background) {
  ready();
  const id = fresh("bitmap");
  const w = Math.max(1, width);
  const h = Math.max(1, height);
  const data = new Uint8Array(w * h * 4);
  for (let i = 3; i < data.length; i += 4) data[i] = 255;
  bitmaps.set(id, { width: w, height: h, data, x1: 0, y1: 0, x2: w, y2: h });
  fill_bitmap(id, background);
  return id;
}

export function set_pixel(b, x, y, color) {
  const bm = bitmaps.get(b);
  if (bm === undefined || x < 0 || y < 0 || x >= bm.width || y >= bm.height) return;
  const at = (y * bm.width + x) * 4;
  bm.data[at] = (color >> 16) & 255;
  bm.data[at + 1] = (color >> 8) & 255;
  bm.data[at + 2] = color & 255;
  if (x < bm.x1) bm.x1 = x;
  if (y < bm.y1) bm.y1 = y;
  if (x >= bm.x2) bm.x2 = x + 1;
  if (y >= bm.y2) bm.y2 = y + 1;
}

export function get_pixel(b, x, y) {
  const bm = bitmaps.get(b);
  if (bm === undefined || x < 0 || y < 0 || x >= bm.width || y >= bm.height) return 0;
  const at = (y * bm.width + x) * 4;
  return (bm.data[at] << 16) | (bm.data[at + 1] << 8) | bm.data[at + 2];
}

export function fill_bitmap(b, color) {
  const bm = bitmaps.get(b);
  if (bm === undefined) return;
  for (let at = 0; at < bm.data.length; at += 4) {
    bm.data[at] = (color >> 16) & 255;
    bm.data[at + 1] = (color >> 8) & 255;
    bm.data[at + 2] = color & 255;
  }
  Object.assign(bm, { x1: 0, y1: 0, x2: bm.width, y2: bm.height });
}

// The width, height and bytes of what the page read of a picture: "width
// height base64", four bytes a pixel; null where the text is not that.
// String -> {width, height, data}?
function picturePixels(pixels) {
  const words = pixels.split(" ");
  if (words.length !== 3 || !/^[0-9]+$/.test(words[0]) || !/^[0-9]+$/.test(words[1])) return null;
  const width = Number(words[0]);
  const height = Number(words[1]);
  let text;
  try {
    text = atob(words[2]);
  } catch (error) {
    return null;
  }
  if (width < 1 || height < 1 || text.length !== width * height * 4) return null;
  const data = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) data[i] = text.charCodeAt(i);
  // A bitmap's pixels are opaque.
  for (let i = 3; i < data.length; i += 4) data[i] = 255;
  return { width, height, data };
}

// Makes the bitmap `b` from what the page read of a picture. False, and
// nothing made, where `b` is a bitmap already -- the picture read again
// for a page connecting later -- or the text is not that.
// String -> String -> Bool
function bitmapFrom(b, pixels) {
  if (bitmaps.has(b)) return false;
  const read = picturePixels(pixels);
  if (read === null) return false;
  const { width, height, data } = read;
  bitmaps.set(b, { width, height, data, x1: 0, y1: 0, x2: width, y2: height });
  return true;
}

export function bitmap_width(b) {
  const bm = bitmaps.get(b);
  return bm === undefined ? 0 : bm.width;
}

export function bitmap_height(b) {
  const bm = bitmaps.get(b);
  return bm === undefined ? 0 : bm.height;
}

export function draw_bitmap(c, b, x, y, scale) {
  const bm = bitmaps.get(b);
  if (bm === undefined) return;
  const changed = bm.x2 > bm.x1 && bm.y2 > bm.y1;
  const rect = changed ? [bm.x1, bm.y1, bm.x2 - bm.x1, bm.y2 - bm.y1] : [0, 0, 0, 0];
  const [rx, ry, rw, rh] = rect;
  const bytes = new Uint8Array(rw * rh * 4);
  for (let r = 0; r < rh; r++) {
    const from = ((ry + r) * bm.width + rx) * 4;
    bytes.set(bm.data.subarray(from, from + rw * 4), r * rw * 4);
  }
  Object.assign(bm, { x1: bm.width, y1: bm.height, x2: 0, y2: 0 });
  send({ op: "bitmap", c, id: b, width: bm.width, height: bm.height, x, y, scale, rect,
    data: Buffer.from(bytes).toString("base64"), digest: digest(bytes) });
}

export function set_state(c, kind, value, numbers) {
  send({ op: "state", c, kind, value, numbers });
}

export function load_image(name) {
  ready();
  const id = fresh(name);
  send({ op: "image_load", id, name });
  return id;
}

export function draw_image(c, picture, x, y, width, height, alpha) {
  send({ op: "image", c, picture, x, y, width, height, alpha });
}

export function make_checkbox(title, checked, onChange) {
  ready();
  const id = fresh(title);
  checks.set(id, onChange);
  send({ op: "checkbox", id, title, checked });
  return id;
}

export function make_radio(group, title, chosen, onPick) {
  ready();
  const id = fresh(title);
  radios.set(id, () => onPick(title));
  send({ op: "radio", id, group, title, chosen });
  return id;
}

export function make_choice(options, chosen, onChange) {
  ready();
  const id = fresh("choice");
  choices.set(id, onChange);
  send({ op: "choice", id, options, chosen });
  return id;
}

export function make_text_input(placeholder, onEnter) {
  ready();
  const id = fresh(placeholder === "" ? "text" : placeholder);
  texts.set(id, onEnter);
  send({ op: "text_input", id, placeholder });
  return id;
}

export function make_number_input(low, high, value, onChange) {
  ready();
  const id = fresh("number");
  sliders.set(id, onChange);
  send({ op: "number", id, low, high, value });
  return id;
}

export function set_checked(id, checked) {
  send({ op: "set_checked", id, checked });
}

export function set_value(id, value) {
  send({ op: "set_value", id, value });
}

export function make_button(title, onClick) {
  ready();
  const id = fresh(title);
  buttons.set(id, onClick);
  send({ op: "button", id, title });
  return id;
}

export function label(text) {
  ready();
  const id = fresh(text);
  send({ op: "label", id, text });
  return id;
}

export function row() {
  ready();
  const id = fresh("row");
  send({ op: "row", id });
  return id;
}

export function column() {
  ready();
  const id = fresh("column");
  send({ op: "column", id });
  return id;
}

export function inside(id) {
  send({ op: "inside", id });
}

export function outside() {
  send({ op: "outside" });
}

export function set_label(id, text) {
  send({ op: "set_label", id, text });
}

export function apply_style(id, kind, property, value) {
  send({ op: "style", id, kind, prop: property, value });
}

export function make_slider(low, high, value, onChange) {
  ready();
  const id = fresh("slider");
  sliders.set(id, onChange);
  send({ op: "slider", id, low, high, value });
  return id;
}

export function load_sample(name) {
  ready();
  const id = fresh(name);
  send({ op: "load", id, name });
  return id;
}

export function fresh_id(name) {
  ready();
  return fresh(name);
}

export function command(kind, id, text, numbers, mode) {
  send({ op: "cmd", kind, id, text, numbers, mode });
}

export function watch(id, kind, f) {
  ready();
  const key = id + "\u0000" + kind;
  if (!watchers.has(key)) watchers.set(key, []);
  watchers.get(key).push(f);
}

export function report_number(name, k) {
  const value = reports.get(name);
  if (!Array.isArray(value) || k < 0 || k >= value.length) return 0.0;
  const n = Number(value[k]);
  return Number.isFinite(n) ? n : 0.0;
}

export function report_text(name) {
  const value = reports.get(name);
  return typeof value === "string" ? value : "";
}

export function report_count(name) {
  const value = reports.get(name);
  return Array.isArray(value) ? value.length : 0;
}

export function watch_text(id, kind, name, f) {
  watch(id, kind, () => f(report_text(name)));
}

export function read_bitmap(name, onLoad) {
  const id = fresh_id("bitmap");
  watch(id, "loaded", () => {
    if (bitmapFrom(id, report_text("pixels." + id))) onLoad(id);
  });
  command("load_bitmap", id, name, "", 0);
}

export function watch_step(id, kind, f) {
  watch(id, kind, () => f(Math.trunc(report_number(kind, 0)) | 0, report_number(kind, 1)));
}

export function watch_pair(id, kind, f) {
  watch(id, kind, () => f(report_number(kind, 0), report_number(kind, 1)));
}

export function splash() {
  ready();
  send({ op: "splash" });
}

export function set_splash(message) {
  ready();
  send({ op: "splash_text", text: message });
}

export function time() {
  ready();
  return clock;
}

// Sends `sdelay` and waits for the page to answer it, delivering the
// page's other events meanwhile. With no page, moves the clock on to
// where it ends instead.
export function sdelay(time) {
  ready();
  const seconds = time > 0 ? time : 0;
  sdelays += 1;
  const id = sdelays;
  send({ op: "sdelay", id, seconds });
  if (LOG !== undefined) {
    sdelayEnd = sdelayEnd === null ? clock + seconds : Math.max(sdelayEnd + seconds, clock);
    clock = sdelayEnd;
    return;
  }
  // Sound played after the first `sdelay` is live: a page connecting
  // later is not sent it, as it is not sent a callback's.
  delivered = true;
  hub.flush();
  hub.waitFor(id);
}

export function on_frame(draw) {
  ready();
  frames.push(draw);
  send({ op: "on_frame" });
}

export function on_mouse(c, click) {
  ready();
  if (!mice.has(c)) mice.set(c, []);
  mice.get(c).push(click);
  send({ op: "on_mouse", c });
}

export function on_key(pressed) {
  ready();
  keys.push(pressed);
  send({ op: "on_key" });
}

export function on_key_up(released) {
  ready();
  keyUps.push(released);
  send({ op: "on_key" });
}

export function key_down(key) {
  ready();
  if (!keysOn && keys.length === 0 && keyUps.length === 0) {
    keysOn = true;
    send({ op: "on_key" });
  }
  return down.has(key);
}

// --- events ---

// Calls what the program handed over for one event, in the order it was
// handed over.
function deliver(event) {
  delivered = true;
  if (typeof event.t === "number") clock = event.t;
  if (event.reports && typeof event.reports === "object") {
    for (const [name, value] of Object.entries(event.reports)) {
      reports.set(name, typeof value === "string" ? value : Array.isArray(value) ? value.map(Number) : [Number(value)]);
    }
  }
  switch (event.ev) {
    case "cb":
      for (const f of (watchers.get(event.id + "\u0000" + event.kind) || []).slice()) f();
      break;
    case "click":
      if (buttons.has(event.id)) buttons.get(event.id)();
      break;
    case "slide":
      if (sliders.has(event.id)) sliders.get(event.id)(Math.trunc(event.value));
      break;
    case "check":
      if (checks.has(event.id)) checks.get(event.id)(event.checked === true);
      break;
    case "pick":
      if (radios.has(event.id)) radios.get(event.id)();
      break;
    case "choose":
      if (choices.has(event.id)) choices.get(event.id)(Math.trunc(event.value));
      break;
    case "enter":
      if (texts.has(event.id)) texts.get(event.id)(String(event.text));
      break;
    case "frame":
      for (const draw of frames.slice()) draw(clock);
      send({ op: "frame_done" });
      break;
    case "mouse":
      for (const click of (mice.get(event.c) || []).slice()) {
        click(Math.trunc(event.x), Math.trunc(event.y));
      }
      break;
    case "key":
      down.add(String(event.key));
      for (const pressed of keys.slice()) pressed(String(event.key));
      break;
    case "key_up":
      down.delete(String(event.key));
      for (const released of keyUps.slice()) released(String(event.key));
      break;
    case "press":
    case "release":
    case "move": {
      const seen = pointers.get(event.c);
      if (seen === undefined) break;
      seen.x = Math.trunc(event.x);
      seen.y = Math.trunc(event.y);
      if (event.ev === "press") seen.down = true;
      if (event.ev === "release") seen.down = false;
      const kinds = event.ev === "move" && seen.down ? ["move", "drag"] : [event.ev];
      for (const kind of kinds) for (const f of seen[kind].slice()) f(seen.x, seen.y);
      break;
    }
    case "measured": {
      const answer = measures.get(event.id);
      if (answer === undefined) break;
      measures.delete(event.id);
      answer(Number(event.width));
      break;
    }
  }
}

// One line of an events file as the event the page would send.
function parseEvent(line) {
  if (line.startsWith("key ")) return { ev: "key", key: line.slice(4) };
  if (line.startsWith("key_up ")) return { ev: "key_up", key: line.slice(7) };
  const kind = line.trim().split(/\s+/)[0];
  if (kind === "cb" || kind === "report" || kind === "report_text") return genericEvent(kind, line);
  const after = line.trim().slice(kind.length).trim();
  if (kind === "frame") {
    const t = Number(after);
    return after !== "" && !Number.isNaN(t) ? { ev: "frame", t } : null;
  }
  // The element is a quoted string, which may hold spaces; so is the text
  // an `enter` carries.
  const quoted = /^"(?:[^"\\]|\\.)*"/;
  const first = quoted.exec(after);
  if (first === null) return null;
  let id;
  try {
    id = JSON.parse(first[0]);
  } catch {
    return null;
  }
  const rest = after.slice(first[0].length).trim();
  if (kind === "enter") {
    const second = quoted.exec(rest);
    if (second === null || rest.slice(second[0].length).trim() !== "") return null;
    try {
      return { ev: "enter", id, text: JSON.parse(second[0]) };
    } catch {
      return null;
    }
  }
  const words = rest === "" ? [] : rest.split(/\s+/);
  if (kind === "check") {
    return words.length === 1 && (words[0] === "true" || words[0] === "false")
      ? { ev: "check", id, checked: words[0] === "true" } : null;
  }
  const n = words.map(Number);
  if (n.some(Number.isNaN)) return null;
  switch (kind) {
    case "click": return n.length === 0 ? { ev: "click", id } : null;
    case "pick": return n.length === 0 ? { ev: "pick", id } : null;
    case "slide": return n.length === 1 ? { ev: "slide", id, value: n[0] } : null;
    case "choose": return n.length === 1 ? { ev: "choose", id, value: n[0] } : null;
    case "mouse": case "press": case "release": case "move":
      return n.length === 2 ? { ev: kind, c: id, x: n[0], y: n[1] } : null;
    case "measured": return n.length === 1 ? { ev: "measured", id, width: n[0] } : null;
    default: return null;
  }
}

// A `cb`, `report` or `report_text` line of an events file: quoted
// strings, then numbers for a report.
function genericEvent(kind, line) {
  const quoted = /^\s*("(?:[^"\\]|\\.)*")/;
  let rest = line.trim().slice(kind.length);
  const strings = [];
  for (let m = quoted.exec(rest); m !== null; m = quoted.exec(rest)) {
    try {
      strings.push(JSON.parse(m[1]));
    } catch {
      return null;
    }
    rest = rest.slice(m[0].length);
  }
  const words = rest.trim() === "" ? [] : rest.trim().split(/\s+/);
  if (kind === "cb") return strings.length === 2 && words.length === 0 ? { ev: "cb", id: strings[0], kind: strings[1] } : null;
  if (kind === "report_text") {
    return strings.length === 2 && words.length === 0
      ? { ev: "report", reports: { [strings[0]]: strings[1] } } : null;
  }
  const n = words.map(Number);
  if (strings.length !== 1 || n.some(Number.isNaN)) return null;
  return { ev: "report", reports: { [strings[0]]: n } };
}

// The events file's events, once the top level has ended.
function afterProgram() {
  if (!EVENTS || !fs.existsSync(EVENTS)) return;
  for (const line of fs.readFileSync(EVENTS, "utf8").split("\n")) {
    if (line.trim() === "") continue;
    writeLog("> " + line);
    const event = parseEvent(line);
    if (event === null) writeLog("! unknown event: " + line);
    else deliver(event);
  }
}

// --- the server ---

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json",
  ".wav": "audio/wav", ".mp3": "audio/mpeg", ".ogg": "audio/ogg",
  ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml",
};

const DRAWING = new Set(["clear", "shape", "text", "state", "image", "bitmap"]);

// The commands a page connecting now has to be sent, once `command` has
// been: everything but sound a callback played and frame bookkeeping,
// less what a later command has made invisible.
function kept(history, command) {
  switch (command.op) {
    case "cmd":
      if (command.mode === 2) return delivered ? history : history.concat([command]);
      if (command.mode === 3) return history;
      if (command.mode === 1) {
        return history.filter((h) => !(h.op === "cmd" && h.kind === command.kind && h.id === command.id))
          .concat([command]);
      }
      return history.concat([command]);
    case "frame_done": case "event_done": return history;
    case "clear":
      return history.filter((h) => !(DRAWING.has(h.op) && h.c === command.c)).concat([command]);
    case "set_label": case "set_checked": case "set_value":
      return history.filter((h) => !(h.op === command.op && h.id === command.id))
        .concat([command]);
    default: return history.concat([command]);
  }
}

// The file a page asks for by `url`: beside where the program runs, and
// a library sample from tinyweb_assets/ beside this file.
function staticFile(url) {
  const parts = decodeURIComponent(url).split("/").filter((p) => p !== "" && p !== ".");
  if (parts.length === 0 || parts.includes("..")) return null;
  const places = [process.cwd()];
  if (parts[0] === "tinyweb_assets") places.push(HERE);
  for (const place of places) {
    const candidate = path.join(place, ...parts);
    try {
      if (fs.statSync(candidate).isFile()) return candidate;
    } catch {
      // not here
    }
  }
  return null;
}

// The page's server, as the program sees it: the server itself runs on a
// worker thread (`Server`, below), which keeps the commands for a page
// connecting later and posts every event back over `port`, adding one
// to `signal` each time so that `sdelay` can wait for one.
class Hub {
  constructor(port) {
    this.pending = [];
    this.batching = false;
    this.signal = new Int32Array(new SharedArrayBuffer(4));
    const channel = new MessageChannel();
    this.port = channel.port1;
    this.worker = new Worker(new URL(import.meta.url), {
      workerData: { tinywebServer: true, port, signal: this.signal.buffer, events: channel.port2 },
      transferList: [channel.port2],
    });
    // The worker answers whether the server listens before the program
    // goes on, so a port in use ends it here and the address is printed
    // before anything the program prints after `web_init`.
    const answer = this.next((message) => message.type === "listening" || message.type === "error");
    if (answer.type === "error") {
      refuse(`tinyweb: cannot serve the page on port ${port}: ${answer.message}`);
    }
    // While the program waits in `sdelay`, this thread is blocked: what it
    // prints has to be written then, not once it is free again.
    process.stdout._handle?.setBlocking?.(true);
    process.stderr._handle?.setBlocking?.(true);
    process.stdout.write(`tinyweb: http://127.0.0.1:${answer.port}/\n`);
    this.port.on("message", (message) => {
      if (message.type === "event") this.receive(message.event);
    });
  }

  send(command) {
    this.pending.push(command);
    if (!this.batching) this.flush();
  }

  // The commands since the last batch, to the server, with whether an
  // event has been delivered, which decides what a page connecting later
  // is sent of them.
  flush() {
    if (this.pending.length === 0) return;
    this.worker.postMessage({ type: "batch", commands: this.pending, delivered });
    this.pending = [];
  }

  // The next message from the server that `wanted` says yes to, waiting
  // for one; the ones before it are dropped. (Object -> Bool) -> Object
  next(wanted) {
    for (;;) {
      const seen = Atomics.load(this.signal, 0);
      for (let got = receiveMessageOnPort(this.port); got !== undefined;
        got = receiveMessageOnPort(this.port)) {
        if (wanted(got.message)) return got.message;
      }
      Atomics.wait(this.signal, 0, seen);
    }
  }

  // Waits for the page to answer `sdelay` number `id`, delivering every
  // other event as it comes, each answered with `event_done`.
  waitFor(id) {
    const batching = this.batching;
    try {
      for (;;) {
        const { event } = this.next((message) => message.type === "event");
        if (event === null || typeof event !== "object") continue;
        if (event.ev === "sdelay") {
          if (event.id === id) {
            deliver(event);
            return;
          }
          continue;
        }
        this.batching = true;
        deliver(event);
        send({ op: "event_done" });
        this.flush();
        this.batching = batching;
      }
    } finally {
      this.batching = batching;
    }
  }

  // Stops serving: the worker ends, so node ends once the program has
  // nothing else to do.
  close() {
    this.port.close();
    this.worker.terminate();
  }

  // One event the page posted: what it causes, then `event_done`. A
  // callback that fails -- `sys.exit` among them -- stops the server and
  // is left to fail as it would have anywhere else.
  receive(event) {
    if (event === null || typeof event !== "object") return;
    const batching = this.batching;
    this.batching = true;
    try {
      deliver(event);
      send({ op: "event_done" });
      this.flush();
    } catch (error) {
      this.close();
      throw error;
    } finally {
      this.batching = batching;
    }
  }
}

// The server itself, on the worker thread: the commands a page
// connecting later has to be sent, every page connected, and how events
// go back to the program.
class Server {
  constructor({ port, signal, events }) {
    this.history = [];
    this.clients = new Set();
    this.signal = new Int32Array(signal);
    this.events = events;
    this.server = http.createServer((request, response) => this.serve(request, response));
    this.server.on("error", (error) => this.post({ type: "error", message: error.message }));
    this.server.listen(port, "127.0.0.1", () => {
      this.post({ type: "listening", port: this.server.address().port });
    });
  }

  // A message to the program, which may be waiting for one.
  post(message) {
    this.events.postMessage(message);
    Atomics.add(this.signal, 0, 1);
    Atomics.notify(this.signal, 0);
  }

  // A batch of commands from the program, kept for a page connecting
  // later and sent to every page connected now.
  batch(commands, wasDelivered) {
    delivered = wasDelivered;
    for (const command of commands) this.history = kept(this.history, command);
    const text = `data: ${JSON.stringify(commands)}\n\n`;
    for (const client of this.clients) client.write(text);
  }

  serve(request, response) {
    const url = request.url.split("?")[0];
    const reply = (status, body, type) => {
      response.writeHead(status, { "Content-Type": type, "Cache-Control": "no-store" });
      response.end(body);
    };
    if (request.method === "POST" && url === "/events") {
      let body = "";
      request.setEncoding("utf8");
      request.on("data", (chunk) => { body += chunk; });
      request.on("end", () => {
        let event = null;
        try {
          event = JSON.parse(body);
        } catch {
          return reply(400, "bad event\n", "text/plain");
        }
        response.writeHead(204);
        response.end();
        // An answered `sdelay` is not sent to a page connecting later.
        if (event !== null && typeof event === "object" && event.ev === "sdelay") {
          this.history = this.history.filter((h) => !(h.op === "sdelay" && h.id === event.id));
        }
        this.post({ type: "event", event });
      });
      return;
    }
    if (request.method !== "GET") return reply(404, "not found\n", "text/plain");
    if (url === "/" || url === "/index.html") return reply(200, PAGE_HTML, TYPES[".html"]);
    if (url === "/tinyweb_page.js") return reply(200, PAGE_JS, TYPES[".js"]);
    if (url === "/commands") {
      response.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store" });
      response.write(": tinyweb\n\n");
      if (this.history.length > 0) response.write(`data: ${JSON.stringify(this.history)}\n\n`);
      this.clients.add(response);
      request.on("close", () => this.clients.delete(response));
      return;
    }
    const found = staticFile(url);
    if (found === null) return reply(404, "not found\n", "text/plain");
    reply(200, fs.readFileSync(found), TYPES[path.extname(found)] || "application/octet-stream");
  }
}

// This file, run on the worker thread `Hub` starts: the server, fed the
// program's commands. Object -> ()
function serveOnWorker(data) {
  const server = new Server(data);
  parentPort.on("message", (message) => {
    if (message.type === "batch") server.batch(message.commands, message.delivered);
  });
}

// BEGIN tinyweb page
// written by tools/tinyweb/embed_page.py from tinyweb_page.html and tinyweb_page.js; do not edit
const PAGE_HTML = [
  "<!doctype html>\n",
  "<!-- The page a program serves after tinyweb.web_init: tinyweb_page.js\n",
  "     carries out the commands the program sends over /commands, and every\n",
  "     event is posted back to /events, in order. Each native\n",
  "     implementation carries a copy of this file, written into it by\n",
  "     tools/tinyweb/embed_page.py. See docs/libraries.md, \"tinyweb\". -->\n",
  "<html lang=\"en\">\n",
  "<head>\n",
  "<meta charset=\"utf-8\">\n",
  "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n",
  "<title>tinyweb</title>\n",
  "<style>\n",
  "  body { margin: 0; padding: 16px; min-height: 100vh; box-sizing: border-box; }\n",
  "  .tinyweb-ended { margin-top: 12px; color: #666666; font-size: 14px; }\n",
  "</style>\n",
  "</head>\n",
  "<body>\n",
  "<script type=\"module\">\n",
  "import { mountPage } from \"./tinyweb_page.js\";\n",
  "\n",
  "// One event at a time, so the program sees them in the order they\n",
  "// happened.\n",
  "let posting = Promise.resolve();\n",
  "function post(event) {\n",
  "  posting = posting\n",
  "    .then(() => fetch(\"/events\", { method: \"POST\", body: JSON.stringify(event) }))\n",
  "    .catch(() => {});\n",
  "}\n",
  "\n",
  "const page = mountPage(document.body, post, { standalone: true });\n",
  "const stream = new EventSource(\"/commands\");\n",
  "stream.onmessage = (message) => page.receive(JSON.parse(message.data));\n",
  "stream.onerror = () => {\n",
  "  stream.close();\n",
  "  page.freeze();\n",
  "  const ended = document.createElement(\"div\");\n",
  "  ended.className = \"tinyweb-ended\";\n",
  "  ended.textContent = \"The program has stopped.\";\n",
  "  document.body.appendChild(ended);\n",
  "};\n",
  "</script>\n",
  "</body>\n",
  "</html>\n",
].join("");
const PAGE_JS = [
  "// tinyweb's page: the renderer that carries out the commands a program\n",
  "// sends and reports the events its reader causes. It is the one copy of\n",
  "// that code, used wherever a program talks to its page in commands:\n",
  "//\n",
  "//   - on an iweb page, where tinyweb_external_interpreter.js mounts it\n",
  "//     and calls it directly;\n",
  "//   - in the playground and the notebook, where the program runs on a\n",
  "//     worker and tools/webrun/assets/pages.js mounts it on the page;\n",
  "//   - on the page a compiled program serves after `web_init`, where\n",
  "//     tinyweb_page.html mounts it and the commands arrive from the\n",
  "//     program over HTTP. Each native implementation carries a copy of\n",
  "//     this file and of tinyweb_page.html, written into it by\n",
  "//     tools/tinyweb/embed_page.py.\n",
  "//\n",
  "// A command is a plain object such as {op: \"circle\", c, x, y, radius,\n",
  "// color}, and an event one such as {ev: \"click\", id}; see\n",
  "// docs/libraries.md, \"tinyweb\". The web implementation,\n",
  "// tinyweb_external_browser.js, does what this file does without the\n",
  "// commands in between. Keep the file ASCII: it is embedded in C.\n",
  "\n",
  "function now() {\n",
  "  return typeof performance !== \"undefined\" ? performance.now() : Date.now();\n",
  "}\n",
  "\n",
  "// BEGIN tinyweb style\n",
  "// The page's look: a theme, what the program changed of it for every\n",
  "// element of a kind, and what it changed of one element. A theme and a\n",
  "// kind's style are rules of a stylesheet of the page's own, scoped to the\n",
  "// element the page is mounted in, so the host page's own rules do not\n",
  "// reach in; one element's style is set on the element. This block is\n",
  "// copied into tinyweb_external_browser.js by tools/tinyweb/embed_page.py.\n",
  "\n",
  "// Each theme: CSS declarations for each place on the page (PLACES).\n",
  "const THEMES = {\n",
  "  light: {\n",
  "    page: { \"background\": \"#f6f6f4\", \"color\": \"#1d1f21\", \"font-family\": \"system-ui, sans-serif\", \"font-size\": \"15px\" },\n",
  "    box: { \"gap\": \"8px\" },\n",
  "    button: {\n",
  "      \"background\": \"#f0f2f5\", \"color\": \"#1f2328\", \"border\": \"1px solid #d4d8de\",\n",
  "      \"border-radius\": \"5px\", \"padding\": \"5px 10px\", \"font-family\": \"inherit\", \"font-size\": \"14px\",\n",
  "    },\n",
  "    \"button:hover\": { \"border-color\": \"#2f5fc4\" },\n",
  "    \"button:active\": { \"background\": \"#e3e7ec\" },\n",
  "    \"slider input\": { \"accent-color\": \"#2f5fc4\" },\n",
  "    canvas: { \"border\": \"1px solid #c9ced6\" },\n",
  "  },\n",
  "  dark: {\n",
  "    page: { \"background\": \"#1d1f21\", \"color\": \"#e6e6e6\", \"font-family\": \"system-ui, sans-serif\", \"font-size\": \"15px\" },\n",
  "    box: { \"gap\": \"8px\" },\n",
  "    button: {\n",
  "      \"background\": \"#2f333a\", \"color\": \"#e6e6e6\", \"border\": \"1px solid #454a52\",\n",
  "      \"border-radius\": \"5px\", \"padding\": \"5px 10px\", \"font-family\": \"inherit\", \"font-size\": \"14px\",\n",
  "    },\n",
  "    \"button:hover\": { \"border-color\": \"#7aa2f7\" },\n",
  "    \"button:active\": { \"background\": \"#3a3f47\" },\n",
  "    \"slider input\": { \"accent-color\": \"#7aa2f7\" },\n",
  "    canvas: { \"border\": \"1px solid #454a52\" },\n",
  "  },\n",
  "  plain: {\n",
  "    page: { \"background\": \"#ffffff\", \"color\": \"#000000\", \"font-family\": \"system-ui, sans-serif\" },\n",
  "    box: { \"gap\": \"8px\" },\n",
  "    canvas: { \"border\": \"1px solid #8884\" },\n",
  "  },\n",
  "  paper: {\n",
  "    page: { \"background\": \"#fbf6ea\", \"color\": \"#3b3024\", \"font-family\": \"Georgia, 'Times New Roman', serif\", \"font-size\": \"16px\" },\n",
  "    box: { \"gap\": \"10px\" },\n",
  "    button: {\n",
  "      \"background\": \"#fffdf7\", \"color\": \"#3b3024\", \"border\": \"1px solid #3b3024\",\n",
  "      \"border-radius\": \"2px\", \"padding\": \"5px 14px\", \"font-family\": \"inherit\", \"font-size\": \"15px\",\n",
  "    },\n",
  "    \"button:hover\": { \"background\": \"#f1e8d2\" },\n",
  "    \"button:active\": { \"background\": \"#e6d9bb\" },\n",
  "    \"slider input\": { \"accent-color\": \"#8a5a2b\" },\n",
  "    canvas: { \"border\": \"1px solid #3b302466\" },\n",
  "  },\n",
  "  retro: {\n",
  "    page: { \"background\": \"#0b1a0b\", \"color\": \"#39ff6a\", \"font-family\": \"'Courier New', monospace\", \"font-size\": \"15px\" },\n",
  "    box: { \"gap\": \"10px\" },\n",
  "    button: {\n",
  "      \"background\": \"#0b1a0b\", \"color\": \"#39ff6a\", \"border\": \"2px solid #39ff6a\",\n",
  "      \"border-radius\": \"0\", \"padding\": \"4px 12px\", \"font-family\": \"inherit\", \"font-size\": \"15px\",\n",
  "    },\n",
  "    \"button:hover\": { \"background\": \"#133313\" },\n",
  "    \"button:active\": { \"background\": \"#39ff6a\", \"color\": \"#0b1a0b\" },\n",
  "    \"slider input\": { \"accent-color\": \"#39ff6a\" },\n",
  "    canvas: { \"border\": \"2px solid #39ff6a\" },\n",
  "  },\n",
  "};\n",
  "\n",
  "// Where each place is, after the page's scope.\n",
  "const PLACES = {\n",
  "  page: \"\",\n",
  "  box: \" > .tinyweb-page\",\n",
  "  button: \" .tinyweb-page button\",\n",
  "  \"button:hover\": \" .tinyweb-page button:hover\",\n",
  "  \"button:active\": \" .tinyweb-page button:active\",\n",
  "  label: \" .tinyweb-page .tinyweb-label\",\n",
  "  slider: \" .tinyweb-page .tinyweb-slider\",\n",
  "  \"slider input\": \" .tinyweb-page .tinyweb-slider input\",\n",
  "  canvas: \" .tinyweb-page canvas\",\n",
  "};\n",
  "\n",
  "// What each property a program names is in CSS.\n",
  "const PROPERTIES = {\n",
  "  background: \"background\", color: \"color\", border: \"border\", radius: \"border-radius\",\n",
  "  font: \"font-family\", size: \"font-size\", padding: \"padding\", gap: \"gap\",\n",
  "  accent: \"accent-color\", width: \"width\", height: \"height\", align: \"align-items\",\n",
  "  weight: \"font-weight\",\n",
  "};\n",
  "\n",
  "// What an `align` a program names is in CSS.\n",
  "const ALIGNMENTS = { left: \"flex-start\", center: \"center\", right: \"flex-end\" };\n",
  "\n",
  "// The place a kind's property goes. String -> String -> String\n",
  "function placeOf(kind, property) {\n",
  "  if (kind === \"page\") return property === \"gap\" || property === \"align\" ? \"box\" : \"page\";\n",
  "  if (kind === \"slider\") return property === \"accent\" || property === \"width\" ? \"slider input\" : \"slider\";\n",
  "  return kind;\n",
  "}\n",
  "\n",
  "let styledPages = 0;\n",
  "\n",
  "// Gives the page mounted in `host` a stylesheet of its own, in the\n",
  "// default theme. Element -> Element -> Style\n",
  "function styled(host, box) {\n",
  "  styledPages += 1;\n",
  "  const sheet = document.createElement(\"style\");\n",
  "  sheet.setAttribute(\"data-tinyweb-style\", String(styledPages));\n",
  "  const style = { host, box, sheet, rules: null, elements: new Map(), name: String(styledPages) };\n",
  "  host.setAttribute(\"data-tinyweb-page\", style.name);\n",
  "  (document.head || document.body).appendChild(sheet);\n",
  "  setTheme(style, \"light\");\n",
  "  return style;\n",
  "}\n",
  "\n",
  "// Writes the stylesheet from the rules. Style -> ()\n",
  "function writeSheet(style) {\n",
  "  // The scope three times over, so the host page's rules for a button or\n",
  "  // a body do not outweigh the page's own.\n",
  "  const scope = `[data-tinyweb-page=\"${style.name}\"]`.repeat(3);\n",
  "  const text = [];\n",
  "  for (const place of Object.keys(PLACES)) {\n",
  "    const declarations = style.rules[place];\n",
  "    if (!declarations || Object.keys(declarations).length === 0) continue;\n",
  "    const body = Object.entries(declarations).map(([k, v]) => `${k}: ${v};`).join(\" \");\n",
  "    text.push(`${scope}${PLACES[place]} { ${body} }`);\n",
  "  }\n",
  "  style.sheet.textContent = text.join(\"\\n\");\n",
  "}\n",
  "\n",
  "// Puts the page in a theme, forgetting what was changed for each kind.\n",
  "// An unknown name changes nothing. Style -> String -> ()\n",
  "function setTheme(style, name) {\n",
  "  const theme = THEMES[name];\n",
  "  if (!theme) return;\n",
  "  style.rules = {};\n",
  "  for (const [place, declarations] of Object.entries(theme)) {\n",
  "    style.rules[place] = { ...declarations };\n",
  "  }\n",
  "  writeSheet(style);\n",
  "}\n",
  "\n",
  "// Remembers a page element by its id, so that its own style can be set.\n",
  "// Style -> Int -> Element -> ()\n",
  "function remember(style, id, element) {\n",
  "  style.elements.set(id, element);\n",
  "}\n",
  "\n",
  "// Carries out one style command: a theme, a property of every element\n",
  "// of a kind, or a property of the element `id` (kind \"element\").\n",
  "// Style -> Int -> String -> String -> String -> ()\n",
  "function applyStyle(style, id, kind, property, given) {\n",
  "  if (kind === \"theme\") {\n",
  "    setTheme(style, given);\n",
  "    return;\n",
  "  }\n",
  "  const css = PROPERTIES[property];\n",
  "  if (!css) return;\n",
  "  const value = property === \"align\" ? ALIGNMENTS[given] || \"flex-start\" : given;\n",
  "  if (kind === \"page\" && property === \"align\") {\n",
  "    // The box says where its elements stand on the element itself.\n",
  "    style.box.style.setProperty(css, value);\n",
  "    return;\n",
  "  }\n",
  "  if (kind === \"element\") {\n",
  "    let element = style.elements.get(id);\n",
  "    if (!element) return;\n",
  "    // A slider's own properties are its input's; the rest are its row's.\n",
  "    if (element.tagName === \"INPUT\" && property !== \"accent\" && property !== \"width\") {\n",
  "      element = element.parentNode;\n",
  "    }\n",
  "    element.style.setProperty(css, value);\n",
  "    return;\n",
  "  }\n",
  "  const place = placeOf(kind, property);\n",
  "  if (!(place in PLACES)) return;\n",
  "  if (!style.rules[place]) style.rules[place] = {};\n",
  "  style.rules[place][css] = value;\n",
  "  writeSheet(style);\n",
  "}\n",
  "\n",
  "// Takes the page's look off the element it was mounted in. Style -> ()\n",
  "function unstyled(style) {\n",
  "  style.sheet.remove();\n",
  "  if (style.host.getAttribute(\"data-tinyweb-page\") === style.name) {\n",
  "    style.host.removeAttribute(\"data-tinyweb-page\");\n",
  "  }\n",
  "}\n",
  "// What the splash screen says until the program sets it.\n",
  "const SPLASH_TEXT = \"Click to Start\";\n",
  "\n",
  "// The splash screen: the whole window dimmed, and `text` in white in\n",
  "// its middle under a play sign. String -> Element\n",
  "function splashScreen(text) {\n",
  "  const screen = document.createElement(\"div\");\n",
  "  screen.className = \"tinyweb-splash\";\n",
  "  screen.setAttribute(\"role\", \"button\");\n",
  "  screen.style.cssText =\n",
  "    \"position:fixed;inset:0;z-index:2147483647;display:flex;flex-direction:column;\" +\n",
  "    \"align-items:center;justify-content:center;gap:24px;background:rgba(0,0,0,0.62);\" +\n",
  "    \"color:#ffffff;cursor:pointer;user-select:none;font-family:system-ui,sans-serif\";\n",
  "  const ring = document.createElement(\"div\");\n",
  "  ring.style.cssText =\n",
  "    \"width:88px;height:88px;border-radius:50%;border:3px solid #ffffff;display:flex;\" +\n",
  "    \"align-items:center;justify-content:center;box-shadow:0 0 36px rgba(255,255,255,0.35)\";\n",
  "  const sign = document.createElement(\"div\");\n",
  "  sign.style.cssText =\n",
  "    \"width:0;height:0;margin-left:9px;border-top:19px solid transparent;\" +\n",
  "    \"border-bottom:19px solid transparent;border-left:32px solid #ffffff\";\n",
  "  ring.appendChild(sign);\n",
  "  const words = document.createElement(\"div\");\n",
  "  words.textContent = text;\n",
  "  words.style.cssText =\n",
  "    \"font-size:34px;font-weight:600;letter-spacing:0.03em;text-align:center;\" +\n",
  "    \"padding:0 24px;text-shadow:0 2px 14px rgba(0,0,0,0.6)\";\n",
  "  screen.append(ring, words);\n",
  "  return screen;\n",
  "}\n",
  "\n",
  "// Whether the reader has already done something on this page, which is\n",
  "// all a browser asks before it plays a sound. () -> Bool\n",
  "function readerActive() {\n",
  "  return Boolean(globalThis.navigator?.userActivation?.hasBeenActive);\n",
  "}\n",
  "// --- drawing (step 1) ---\n",
  "\n",
  "// A shape's numbers: the words tinyweb.pyk wrote, as numbers.\n",
  "function numbersOf(text) {\n",
  "  return text === \"\" ? [] : text.split(\" \").map(Number);\n",
  "}\n",
  "\n",
  "// A rectangle with rounded corners, as a path. Context -> ... -> ()\n",
  "function roundedRect(g, x, y, w, h, r) {\n",
  "  const k = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));\n",
  "  g.moveTo(x + k, y);\n",
  "  g.arcTo(x + w, y, x + w, y + h, k);\n",
  "  g.arcTo(x + w, y + h, x, y + h, k);\n",
  "  g.arcTo(x, y + h, x, y, k);\n",
  "  g.arcTo(x, y, x + w, y, k);\n",
  "  g.closePath();\n",
  "}\n",
  "\n",
  "// The outline of one shape, added to the context's path. Whether a filled\n",
  "// arc is a slice from its centre is `slice`'s.\n",
  "// Context -> String -> [Float] -> Bool -> ()\n",
  "function shapePath(g, kind, n, slice) {\n",
  "  switch (kind) {\n",
  "    case \"rect\":\n",
  "      if (n[4] > 0) roundedRect(g, n[0], n[1], n[2], n[3], n[4]);\n",
  "      else g.rect(n[0], n[1], n[2], n[3]);\n",
  "      break;\n",
  "    case \"circle\":\n",
  "      g.arc(n[0], n[1], Math.max(0, n[2]), 0, 2 * Math.PI);\n",
  "      break;\n",
  "    case \"ellipse\":\n",
  "      g.ellipse(n[0], n[1], Math.max(0, n[2]), Math.max(0, n[3]), 0, 0, 2 * Math.PI);\n",
  "      break;\n",
  "    case \"arc\":\n",
  "      if (slice) g.moveTo(n[0], n[1]);\n",
  "      g.arc(n[0], n[1], Math.max(0, n[2]), n[3], n[4]);\n",
  "      if (slice) g.closePath();\n",
  "      break;\n",
  "    case \"line\":\n",
  "      g.moveTo(n[0], n[1]);\n",
  "      g.lineTo(n[2], n[3]);\n",
  "      break;\n",
  "    case \"lines\":\n",
  "      for (let i = 0; i + 3 < n.length; i += 4) {\n",
  "        g.moveTo(n[i], n[i + 1]);\n",
  "        g.lineTo(n[i + 2], n[i + 3]);\n",
  "      }\n",
  "      break;\n",
  "    case \"curve\":\n",
  "      g.moveTo(n[0], n[1]);\n",
  "      g.quadraticCurveTo(n[2], n[3], n[4], n[5]);\n",
  "      break;\n",
  "    case \"bezier\":\n",
  "      g.moveTo(n[0], n[1]);\n",
  "      g.bezierCurveTo(n[2], n[3], n[4], n[5], n[6], n[7]);\n",
  "      break;\n",
  "    case \"polygon\":\n",
  "    case \"path\":\n",
  "      for (let i = 0; i + 1 < n.length; i += 2) {\n",
  "        if (i === 0) g.moveTo(n[i], n[i + 1]);\n",
  "        else g.lineTo(n[i], n[i + 1]);\n",
  "      }\n",
  "      if (kind === \"polygon\") g.closePath();\n",
  "      break;\n",
  "  }\n",
  "}\n",
  "\n",
  "// The gradients a canvas has been given, by the text that describes\n",
  "// them, so a frame drawing the same one again does not make it again.\n",
  "const GRADIENTS_KEPT = 64;\n",
  "\n",
  "// What a color means on a context: a CSS color as it is, and a gradient\n",
  "// tinyweb.pyk described -- \"linear-gradient(x1 y1 x2 y2); 0 red; 1 blue\",\n",
  "// \"radial-gradient(x1 y1 r1 x2 y2 r2); ...\", \"conic-gradient(x y\n",
  "// angle); ...\" -- as the gradient. Context -> Entry? -> String -> Paint\n",
  "function paint(g, entry, color) {\n",
  "  const open = color.indexOf(\"(\");\n",
  "  if (open < 0 || !color.slice(0, open).endsWith(\"-gradient\")) return color;\n",
  "  const close = color.indexOf(\")\", open);\n",
  "  if (close < 0 || color.slice(close + 1, close + 2) !== \";\") return color;\n",
  "  const kept = entry ? entry.gradients : null;\n",
  "  if (kept && kept.has(color)) return kept.get(color);\n",
  "  const kind = color.slice(0, open);\n",
  "  const n = numbersOf(color.slice(open + 1, close).trim());\n",
  "  let gradient;\n",
  "  if (kind === \"linear-gradient\") gradient = g.createLinearGradient(n[0], n[1], n[2], n[3]);\n",
  "  else if (kind === \"radial-gradient\")\n",
  "    gradient = g.createRadialGradient(n[0], n[1], Math.max(0, n[2]), n[3], n[4], Math.max(0, n[5]));\n",
  "  else if (kind === \"conic-gradient\" && typeof g.createConicGradient === \"function\")\n",
  "    gradient = g.createConicGradient(n[2], n[0], n[1]);\n",
  "  else return \"#000000\";\n",
  "  // A stop's color may itself hold brackets and commas, \"rgba(0, 0, 0, 0.5)\",\n",
  "  // but never a semicolon.\n",
  "  for (const stop of color.slice(close + 2).split(\";\")) {\n",
  "    const text = stop.trim();\n",
  "    const space = text.indexOf(\" \");\n",
  "    if (space < 0) continue;\n",
  "    const at = Math.min(1, Math.max(0, Number(text.slice(0, space))));\n",
  "    try {\n",
  "      gradient.addColorStop(at, text.slice(space + 1).trim());\n",
  "    } catch (error) {\n",
  "      // A stop whose color the browser does not read is left out.\n",
  "    }\n",
  "  }\n",
  "  if (kept) {\n",
  "    if (kept.size >= GRADIENTS_KEPT) kept.delete(kept.keys().next().value);\n",
  "    kept.set(color, gradient);\n",
  "  }\n",
  "  return gradient;\n",
  "}\n",
  "\n",
  "// Draws one shape: filled with `color` and outlined with `outline`, each\n",
  "// unless it is \"\", at `alpha`, in the canvas's line style. The numbers\n",
  "// are the kind's own (see tinyweb.pyk), as words or as an array;\n",
  "// \"erase\" makes its rectangle transparent, and \"circles\" draws each\n",
  "// circle on its own. Context -> Entry? -> String -> Numbers -> ... -> ()\n",
  "function drawShape(g, entry, kind, numbers, color, outline, width, alpha) {\n",
  "  const n = typeof numbers === \"string\" ? numbersOf(numbers) : numbers;\n",
  "  if (kind === \"erase\") {\n",
  "    g.clearRect(n[0], n[1], n[2], n[3]);\n",
  "    return;\n",
  "  }\n",
  "  const before = g.globalAlpha;\n",
  "  g.globalAlpha = before * alpha;\n",
  "  if (kind === \"circles\") {\n",
  "    // Each circle on its own, so where two overlap both show.\n",
  "    if (color !== \"\") g.fillStyle = paint(g, entry, color);\n",
  "    if (outline !== \"\") {\n",
  "      g.strokeStyle = paint(g, entry, outline);\n",
  "      g.lineWidth = width;\n",
  "    }\n",
  "    for (let i = 0; i + 2 < n.length; i += 3) {\n",
  "      g.beginPath();\n",
  "      g.arc(n[i], n[i + 1], Math.max(0, n[i + 2]), 0, 2 * Math.PI);\n",
  "      if (color !== \"\") g.fill();\n",
  "      if (outline !== \"\") g.stroke();\n",
  "    }\n",
  "    g.globalAlpha = before;\n",
  "    return;\n",
  "  }\n",
  "  g.beginPath();\n",
  "  shapePath(g, kind, n, color !== \"\");\n",
  "  if (color !== \"\") {\n",
  "    g.fillStyle = paint(g, entry, color);\n",
  "    g.fill();\n",
  "  }\n",
  "  if (outline !== \"\") {\n",
  "    g.strokeStyle = paint(g, entry, outline);\n",
  "    g.lineWidth = width;\n",
  "    g.stroke();\n",
  "  }\n",
  "  g.globalAlpha = before;\n",
  "}\n",
  "\n",
  "// The font text is written in. Int -> String -> Bool -> String\n",
  "function fontOf(size, font, bold) {\n",
  "  return `${bold ? \"bold \" : \"\"}${size}px ${font === \"\" ? \"system-ui, sans-serif\" : font}`;\n",
  "}\n",
  "\n",
  "// Writes text at (x, y): its left end there, its middle or its right end,\n",
  "// as `align` says, and its top, middle, alphabetic baseline or bottom,\n",
  "// as `baseline` says. An `outline` is drawn round the letters first.\n",
  "// Context -> Entry? -> ... -> ()\n",
  "function drawText(g, entry, x, y, words, color, size, font, align, baseline, bold, outline,\n",
  "  outlineWidth, alpha) {\n",
  "  const before = g.globalAlpha;\n",
  "  g.globalAlpha = before * alpha;\n",
  "  g.font = fontOf(size, font, bold);\n",
  "  g.textBaseline = [\"top\", \"middle\", \"alphabetic\", \"bottom\"].includes(baseline) ? baseline : \"top\";\n",
  "  g.textAlign = align === \"center\" || align === \"right\" ? align : \"left\";\n",
  "  if (outline !== \"\") {\n",
  "    g.strokeStyle = paint(g, entry, outline);\n",
  "    g.lineWidth = outlineWidth;\n",
  "    g.strokeText(words, x, y);\n",
  "  }\n",
  "  if (color !== \"\") {\n",
  "    g.fillStyle = paint(g, entry, color);\n",
  "    g.fillText(words, x, y);\n",
  "  }\n",
  "  g.globalAlpha = before;\n",
  "}\n",
  "\n",
  "// How wide `words` is written in that font, in pixels.\n",
  "// String -> Int -> String -> Bool -> Float\n",
  "function textWidth(words, size, font, bold) {\n",
  "  if (typeof document === \"undefined\") return 0;\n",
  "  if (!textWidth.context) textWidth.context = document.createElement(\"canvas\").getContext(\"2d\");\n",
  "  const g = textWidth.context;\n",
  "  if (!g) return 0;\n",
  "  g.font = fontOf(size, font, bold);\n",
  "  return g.measureText(words).width;\n",
  "}\n",
  "\n",
  "// The line style a canvas starts with: round ends and corners, no dashes.\n",
  "// Context -> ()\n",
  "function plainLines(g) {\n",
  "  g.lineCap = \"round\";\n",
  "  g.lineJoin = \"round\";\n",
  "  if (typeof g.setLineDash === \"function\") g.setLineDash([]);\n",
  "  g.lineDashOffset = 0;\n",
  "}\n",
  "\n",
  "// Changes what the next drawing on a canvas is drawn with. `entry` keeps\n",
  "// the canvas's pixel ratio and how many `push`es are open.\n",
  "// Context -> Entry -> String -> String -> String -> ()\n",
  "function canvasState(g, entry, kind, value, numbers) {\n",
  "  const n = numbersOf(numbers);\n",
  "  switch (kind) {\n",
  "    case \"translate\":\n",
  "      g.translate(n[0], n[1]);\n",
  "      break;\n",
  "    case \"rotate\":\n",
  "      g.rotate(n[0]);\n",
  "      break;\n",
  "    case \"scale\":\n",
  "      g.scale(n[0], n[1]);\n",
  "      break;\n",
  "    case \"push\":\n",
  "      g.save();\n",
  "      entry.depth += 1;\n",
  "      break;\n",
  "    case \"pop\":\n",
  "      if (entry.depth > 0) {\n",
  "        g.restore();\n",
  "        entry.depth -= 1;\n",
  "      }\n",
  "      break;\n",
  "    case \"reset\":\n",
  "      g.setTransform(entry.ratio, 0, 0, entry.ratio, 0, 0);\n",
  "      break;\n",
  "    case \"shadow\":\n",
  "      g.shadowColor = value === \"\" ? \"transparent\" : value;\n",
  "      g.shadowBlur = value === \"\" ? 0 : n[0];\n",
  "      g.shadowOffsetX = value === \"\" ? 0 : n[1];\n",
  "      g.shadowOffsetY = value === \"\" ? 0 : n[2];\n",
  "      break;\n",
  "    case \"blend\":\n",
  "      g.globalCompositeOperation = value === \"add\" ? \"lighter\" : \"source-over\";\n",
  "      break;\n",
  "    case \"line_style\": {\n",
  "      // value: the ends and the corners; numbers: the dash offset, then\n",
  "      // the lengths of the dashes and the gaps.\n",
  "      const [cap, join] = value.split(\" \");\n",
  "      g.lineCap = [\"butt\", \"round\", \"square\"].includes(cap) ? cap : \"round\";\n",
  "      g.lineJoin = [\"miter\", \"round\", \"bevel\"].includes(join) ? join : \"round\";\n",
  "      if (typeof g.setLineDash === \"function\") g.setLineDash(n.slice(1));\n",
  "      g.lineDashOffset = n.length > 0 ? n[0] : 0;\n",
  "      break;\n",
  "    }\n",
  "    case \"clip\":\n",
  "      // value: the kind of shape the drawing is kept inside.\n",
  "      g.beginPath();\n",
  "      shapePath(g, value, n, false);\n",
  "      g.clip();\n",
  "      break;\n",
  "  }\n",
  "}\n",
  "\n",
  "// A canvas as it starts: every `push` closed, no transformation but the\n",
  "// pixel ratio, no shadow, no blending, no clipping and plain lines. What\n",
  "// `clear` begins with. Context -> Entry -> ()\n",
  "function freshState(g, entry) {\n",
  "  while (entry.depth > 0) {\n",
  "    g.restore();\n",
  "    entry.depth -= 1;\n",
  "  }\n",
  "  g.setTransform(entry.ratio, 0, 0, entry.ratio, 0, 0);\n",
  "  g.globalAlpha = 1;\n",
  "  g.shadowColor = \"transparent\";\n",
  "  g.shadowBlur = 0;\n",
  "  g.shadowOffsetX = 0;\n",
  "  g.shadowOffsetY = 0;\n",
  "  g.globalCompositeOperation = \"source-over\";\n",
  "  plainLines(g);\n",
  "}\n",
  "\n",
  "// Starts loading a picture: beside the page first, then among the ones\n",
  "// tinyweb ships beside `base`. Answers what `drawPicture` draws once it\n",
  "// has loaded; `loading` is true until it has loaded or failed, and then\n",
  "// each function in `settled` is called. String -> String -> Picture\n",
  "function loadPicture(name, base) {\n",
  "  const picture = { element: null, ready: false, retried: false, loading: false, settled: [] };\n",
  "  if (typeof Image === \"undefined\") return picture;\n",
  "  const element = new Image();\n",
  "  picture.element = element;\n",
  "  picture.loading = true;\n",
  "  const settle = () => {\n",
  "    picture.loading = false;\n",
  "    for (const then of picture.settled.splice(0)) then();\n",
  "  };\n",
  "  element.onload = () => {\n",
  "    picture.ready = true;\n",
  "    settle();\n",
  "  };\n",
  "  element.onerror = () => {\n",
  "    if (picture.retried) {\n",
  "      console.error(`tinyweb: cannot load the picture ${name}`);\n",
  "      settle();\n",
  "      return;\n",
  "    }\n",
  "    picture.retried = true;\n",
  "    element.src = new URL(\"tinyweb_assets/\" + name, base).href;\n",
  "  };\n",
  "  element.src = new URL(name, document.baseURI).href;\n",
  "  return picture;\n",
  "}\n",
  "\n",
  "// Draws a picture that has loaded; one still loading is not drawn.\n",
  "// Context -> Picture? -> ... -> ()\n",
  "function drawPicture(g, picture, x, y, width, height, alpha) {\n",
  "  if (!picture || !picture.ready) return;\n",
  "  const before = g.globalAlpha;\n",
  "  g.globalAlpha = before * alpha;\n",
  "  g.drawImage(picture.element, x, y, width, height);\n",
  "  g.globalAlpha = before;\n",
  "}\n",
  "\n",
  "// Reads the pixels of the picture `name` for `bitmap.load_bitmap` and\n",
  "// calls `then` with them as the program takes them: \"width height\n",
  "// base64\", the base64 of four bytes a pixel, red, green, blue and alpha.\n",
  "// A picture that cannot be loaded, or has no size, is said on the\n",
  "// console, and `then` is not called. String -> String -> (String -> ()) -> ()\n",
  "function readPicture(name, base, then) {\n",
  "  const picture = loadPicture(name, base);\n",
  "  if (!picture.element) return;\n",
  "  picture.settled.push(() => {\n",
  "    if (!picture.ready) return;\n",
  "    const element = picture.element;\n",
  "    const width = element.naturalWidth;\n",
  "    const height = element.naturalHeight;\n",
  "    // A picture with no size of its own, as an SVG may be, has no pixels.\n",
  "    if (!(width >= 1 && height >= 1)) {\n",
  "      console.error(`tinyweb: the picture ${name} has no size, so no pixels to read`);\n",
  "      return;\n",
  "    }\n",
  "    const surface = bitmapSurface(width, height);\n",
  "    surface.context.drawImage(element, 0, 0);\n",
  "    const bytes = surface.context.getImageData(0, 0, width, height).data;\n",
  "    let text = \"\";\n",
  "    for (let at = 0; at < bytes.length; at += 0x8000) {\n",
  "      text += String.fromCharCode.apply(null, bytes.subarray(at, at + 0x8000));\n",
  "    }\n",
  "    then(width + \" \" + height + \" \" + btoa(text));\n",
  "  });\n",
  "}\n",
  "\n",
  "// Keeps the pointer's moves and its release coming to the canvas it went\n",
  "// down on, wherever it goes. Element -> Event -> ()\n",
  "function capture(element, event) {\n",
  "  try {\n",
  "    if (element.setPointerCapture) element.setPointerCapture(event.pointerId);\n",
  "  } catch (error) {\n",
  "    // A pointer the browser does not know of, as a test's is, is not held.\n",
  "  }\n",
  "}\n",
  "\n",
  "// --- bitmaps (step 5) ---\n",
  "\n",
  "// The bytes of a bitmap's rectangle as they arrive: a base64 string from\n",
  "// a program on another host, or the bytes themselves. Data -> Uint8ClampedArray\n",
  "function bitmapBytes(data) {\n",
  "  if (typeof data !== \"string\") {\n",
  "    return ArrayBuffer.isView(data)\n",
  "      ? new Uint8ClampedArray(data.buffer, data.byteOffset, data.byteLength)\n",
  "      : new Uint8ClampedArray(data);\n",
  "  }\n",
  "  const text = atob(data);\n",
  "  const bytes = new Uint8ClampedArray(text.length);\n",
  "  for (let i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i);\n",
  "  return bytes;\n",
  "}\n",
  "\n",
  "// A bitmap as the page keeps it: a canvas of its own, its pixels.\n",
  "// Int -> Int -> Surface\n",
  "function bitmapSurface(width, height) {\n",
  "  const element = document.createElement(\"canvas\");\n",
  "  element.width = Math.max(1, width);\n",
  "  element.height = Math.max(1, height);\n",
  "  return { element, context: element.getContext(\"2d\"), width, height };\n",
  "}\n",
  "\n",
  "// Puts the rectangle (rx, ry, rw, rh) of a bitmap's pixels on its\n",
  "// surface. Surface -> Int -> Int -> Int -> Int -> Data -> ()\n",
  "function updateSurface(surface, rx, ry, rw, rh, data) {\n",
  "  if (rw <= 0 || rh <= 0) return;\n",
  "  const bytes = bitmapBytes(data);\n",
  "  if (bytes.length !== rw * rh * 4) return;\n",
  "  surface.context.putImageData(new ImageData(bytes, rw, rh), rx, ry);\n",
  "}\n",
  "\n",
  "// Draws a bitmap's surface with its top left corner at (x, y), each pixel\n",
  "// `scale` pixels across: sharp squares when it grows, smooth when it\n",
  "// shrinks. Context -> Surface -> Float -> Float -> Float -> ()\n",
  "function drawSurface(g, surface, x, y, scale) {\n",
  "  const smoothing = g.imageSmoothingEnabled;\n",
  "  g.imageSmoothingEnabled = scale < 1;\n",
  "  g.drawImage(surface.element, x, y, surface.width * scale, surface.height * scale);\n",
  "  g.imageSmoothingEnabled = smoothing;\n",
  "}\n",
  "\n",
  "// A box whose elements go side by side, wrapping where the page is too\n",
  "// narrow for them, or one below another. String -> Bool -> Element\n",
  "function rowElement(id, across = true) {\n",
  "  const row = document.createElement(\"div\");\n",
  "  row.className = across ? \"tinyweb-row\" : \"tinyweb-column\";\n",
  "  row.setAttribute(\"data-tinyweb-id\", id);\n",
  "  row.style.cssText = across\n",
  "    ? \"display:flex;flex-direction:row;flex-wrap:wrap;align-items:center;gap:8px\"\n",
  "    : \"display:flex;flex-direction:column;align-items:flex-start;gap:6px\";\n",
  "  return row;\n",
  "}\n",
  "\n",
  "// --- widgets (step 2) ---\n",
  "\n",
  "// A checkbox or a radio button with its title beside it: the row, and\n",
  "// the input in it. String -> String -> String -> Bool -> (Element, Element)\n",
  "function choiceRow(type, id, title, checked) {\n",
  "  const row = document.createElement(\"label\");\n",
  "  row.className = type === \"checkbox\" ? \"tinyweb-check\" : \"tinyweb-radio\";\n",
  "  row.style.cssText = \"display:flex;align-items:center;gap:6px\";\n",
  "  const input = document.createElement(\"input\");\n",
  "  input.type = type;\n",
  "  input.setAttribute(\"data-tinyweb-id\", id);\n",
  "  input.checked = checked;\n",
  "  const text = document.createElement(\"span\");\n",
  "  text.textContent = title;\n",
  "  row.append(input, text);\n",
  "  return { row, input };\n",
  "}\n",
  "\n",
  "// A dropdown of the options, one per line of `options`, the one at\n",
  "// `chosen` chosen. String -> String -> Int -> Element\n",
  "function choiceElement(id, options, chosen) {\n",
  "  const select = document.createElement(\"select\");\n",
  "  select.className = \"tinyweb-choice\";\n",
  "  select.setAttribute(\"data-tinyweb-id\", id);\n",
  "  options.split(\"\\n\").forEach((text, position) => {\n",
  "    const option = document.createElement(\"option\");\n",
  "    option.value = String(position);\n",
  "    option.textContent = text;\n",
  "    select.appendChild(option);\n",
  "  });\n",
  "  select.value = String(chosen);\n",
  "  return select;\n",
  "}\n",
  "\n",
  "// A line to type text into. String -> String -> Element\n",
  "function textInputElement(id, placeholder) {\n",
  "  const input = document.createElement(\"input\");\n",
  "  input.type = \"text\";\n",
  "  input.className = \"tinyweb-text\";\n",
  "  input.setAttribute(\"data-tinyweb-id\", id);\n",
  "  input.placeholder = placeholder;\n",
  "  return input;\n",
  "}\n",
  "\n",
  "// A field for a whole number from `low` to `high`. ... -> Element\n",
  "function numberElement(id, low, high, value) {\n",
  "  const input = document.createElement(\"input\");\n",
  "  input.type = \"number\";\n",
  "  input.className = \"tinyweb-number\";\n",
  "  input.setAttribute(\"data-tinyweb-id\", id);\n",
  "  input.min = String(low);\n",
  "  input.max = String(high);\n",
  "  input.value = String(value);\n",
  "  return input;\n",
  "}\n",
  "\n",
  "// Whether a key press is the reader typing into a field, which the page\n",
  "// does not report as a key. Event -> Bool\n",
  "function typedInField(event) {\n",
  "  const target = event.target;\n",
  "  return !!target && typeof target.tagName === \"string\"\n",
  "    && (target.tagName === \"SELECT\"\n",
  "      || target.tagName === \"TEXTAREA\"\n",
  "      || (target.tagName === \"INPUT\" && (target.type === \"text\" || target.type === \"number\")));\n",
  "}\n",
  "\n",
  "// --- the engine: sound, the beat, timers and changing the page ---\n",
  "// What every `cmd` command does, the same for the page a program sends\n",
  "// commands to and for web, which calls it directly: makeEngine(host)\n",
  "// answers {command(cmd), reports(withSound), frozen(), held(cmd), close()}.\n",
  "// `host` is what the engine needs of the page:\n",
  "//   audio() -- the AudioContext once sound has started, or null\n",
  "//   startAudio() -- starts sound, where the reader has already done something\n",
  "//   clock() -- the page's clock, in seconds\n",
  "//   toAudio(t) -- a time on the page's clock as a time on the audio clock\n",
  "//   thaw(t) -- the clock goes on from `t` after a pause\n",
  "//   sample(id) -- a sample's loading, a Promise of its AudioBuffer (or null)\n",
  "//   addSample(id, loading) -- a sample loaded another way: a file the reader chose\n",
  "//   element(id) -- an element by its identifier; forget(id) when it is removed\n",
  "//   remember(id, element), place(element) -- a new element, put on the page\n",
  "//   canvas(id) -- a canvas's {element, width, height}\n",
  "//   send(event) -- reports an event to the program\n",
  "\n",
  "// How far ahead the beat is scheduled, and how often it is looked at.\n",
  "const LOOKAHEAD = 0.15;\n",
  "const TICK_MS = 25;\n",
  "\n",
  "// How long before an `sdelay` ends the page answers it, so that what the\n",
  "// program plays next reaches the page in time to start exactly there,\n",
  "// and how often the clock is looked at while one waits.\n",
  "const SDELAY_LEAD = 0.05;\n",
  "const SDELAY_TICK_MS = 5;\n",
  "\n",
  "// The numbers a command carries. String -> [Float]\n",
  "function engineNumbers(text) {\n",
  "  return text === \"\" || text === undefined ? [] : String(text).trim().split(/\\s+/).map(Number);\n",
  "}\n",
  "\n",
  "// A buffer played backwards, made once per buffer. AudioContext -> AudioBuffer -> AudioBuffer\n",
  "const reversedBuffers = new WeakMap();\n",
  "function reversedOf(context, buffer) {\n",
  "  let done = reversedBuffers.get(buffer);\n",
  "  if (done) return done;\n",
  "  done = context.createBuffer(buffer.numberOfChannels, buffer.length, buffer.sampleRate);\n",
  "  for (let k = 0; k < buffer.numberOfChannels; k++) {\n",
  "    const from = buffer.getChannelData(k);\n",
  "    const to = done.getChannelData(k);\n",
  "    for (let i = 0, n = from.length; i < n; i++) to[i] = from[n - 1 - i];\n",
  "  }\n",
  "  reversedBuffers.set(buffer, done);\n",
  "  return done;\n",
  "}\n",
  "\n",
  "// A reverb's impulse: two seconds of noise dying away. AudioContext -> AudioBuffer\n",
  "function impulseOf(context) {\n",
  "  const length = Math.round(context.sampleRate * 2);\n",
  "  const impulse = context.createBuffer(2, length, context.sampleRate);\n",
  "  // The same noise every time, so a render comes out the same.\n",
  "  let seed = 22222;\n",
  "  const random = () => {\n",
  "    seed = (seed * 1103515245 + 12345) % 2147483648;\n",
  "    return seed / 2147483648;\n",
  "  };\n",
  "  for (let k = 0; k < 2; k++) {\n",
  "    const data = impulse.getChannelData(k);\n",
  "    for (let i = 0; i < length; i++) data[i] = (random() * 2 - 1) * Math.pow(1 - i / length, 3);\n",
  "  }\n",
  "  return impulse;\n",
  "}\n",
  "\n",
  "// A channel's settings as `channel_style` gives them.\n",
  "const CHANNEL_DEFAULT = { volume: 1, pan: 0, echo: 0, echoTime: 0.3, feedback: 0.35, reverb: 0, lowPass: 0 };\n",
  "\n",
  "// The sound graph of one AudioContext: a master volume, an analyser on\n",
  "// it, and the channels each sound goes through: volume, pan, a low-pass\n",
  "// filter, and sends to an echo and a reverb. AudioContext -> {..}\n",
  "function soundGraph(context) {\n",
  "  const master = context.createGain();\n",
  "  const analyser = context.createAnalyser ? context.createAnalyser() : null;\n",
  "  if (analyser) {\n",
  "    master.connect(analyser);\n",
  "    analyser.connect(context.destination);\n",
  "  } else {\n",
  "    master.connect(context.destination);\n",
  "  }\n",
  "  const channels = new Map();\n",
  "  let impulse = null;\n",
  "  function channel(n) {\n",
  "    let ch = channels.get(n);\n",
  "    if (ch) return ch;\n",
  "    const input = context.createGain();\n",
  "    const panner = context.createStereoPanner ? context.createStereoPanner() : null;\n",
  "    const filter = context.createBiquadFilter();\n",
  "    filter.type = \"lowpass\";\n",
  "    filter.frequency.value = 22050;\n",
  "    const out = context.createGain();\n",
  "    if (panner) input.connect(panner).connect(filter);\n",
  "    else input.connect(filter);\n",
  "    filter.connect(out);\n",
  "    out.connect(master);\n",
  "    const delay = context.createDelay(5);\n",
  "    const feedback = context.createGain();\n",
  "    const echo = context.createGain();\n",
  "    echo.gain.value = 0;\n",
  "    out.connect(echo);\n",
  "    echo.connect(delay);\n",
  "    delay.connect(feedback);\n",
  "    feedback.connect(delay);\n",
  "    delay.connect(master);\n",
  "    const reverb = context.createGain();\n",
  "    reverb.gain.value = 0;\n",
  "    let convolver = null;\n",
  "    ch = { input, panner, filter, out, delay, feedback, echo, reverb, convolver };\n",
  "    channels.set(n, ch);\n",
  "    return ch;\n",
  "  }\n",
  "  function style(n, settings) {\n",
  "    const ch = channel(n);\n",
  "    ch.out.gain.value = settings.volume;\n",
  "    if (ch.panner) ch.panner.pan.value = Math.max(-1, Math.min(1, settings.pan));\n",
  "    ch.filter.frequency.value = settings.lowPass > 0 ? settings.lowPass : 22050;\n",
  "    ch.echo.gain.value = settings.echo;\n",
  "    ch.delay.delayTime.value = Math.max(0.001, Math.min(5, settings.echoTime));\n",
  "    ch.feedback.gain.value = Math.max(0, Math.min(0.95, settings.feedback));\n",
  "    if (settings.reverb > 0 && ch.convolver === null && context.createConvolver) {\n",
  "      if (impulse === null) impulse = impulseOf(context);\n",
  "      ch.convolver = context.createConvolver();\n",
  "      ch.convolver.buffer = impulse;\n",
  "      ch.out.connect(ch.reverb);\n",
  "      ch.reverb.connect(ch.convolver);\n",
  "      ch.convolver.connect(master);\n",
  "    }\n",
  "    ch.reverb.gain.value = settings.reverb;\n",
  "  }\n",
  "  return { context, master, analyser, channel, style };\n",
  "}\n",
  "\n",
  "// A WAV file of a rendered buffer, 16 bits, as bytes. AudioBuffer -> Uint8Array\n",
  "function wavBytes(buffer) {\n",
  "  const channels = buffer.numberOfChannels;\n",
  "  const frames = buffer.length;\n",
  "  const bytes = new Uint8Array(44 + frames * channels * 2);\n",
  "  const view = new DataView(bytes.buffer);\n",
  "  const text = (at, s) => { for (let i = 0; i < s.length; i++) bytes[at + i] = s.charCodeAt(i); };\n",
  "  text(0, \"RIFF\");\n",
  "  view.setUint32(4, 36 + frames * channels * 2, true);\n",
  "  text(8, \"WAVEfmt \");\n",
  "  view.setUint32(16, 16, true);\n",
  "  view.setUint16(20, 1, true);\n",
  "  view.setUint16(22, channels, true);\n",
  "  view.setUint32(24, buffer.sampleRate, true);\n",
  "  view.setUint32(28, buffer.sampleRate * channels * 2, true);\n",
  "  view.setUint16(32, channels * 2, true);\n",
  "  view.setUint16(34, 16, true);\n",
  "  text(36, \"data\");\n",
  "  view.setUint32(40, frames * channels * 2, true);\n",
  "  const data = [];\n",
  "  for (let k = 0; k < channels; k++) data.push(buffer.getChannelData(k));\n",
  "  let at = 44;\n",
  "  for (let i = 0; i < frames; i++) {\n",
  "    for (let k = 0; k < channels; k++) {\n",
  "      const v = Math.max(-1, Math.min(1, data[k][i]));\n",
  "      view.setInt16(at, v < 0 ? v * 0x8000 : v * 0x7fff, true);\n",
  "      at += 2;\n",
  "    }\n",
  "  }\n",
  "  return bytes;\n",
  "}\n",
  "\n",
  "// Offers `blob` to the reader as a file called `name`. Blob -> String -> ()\n",
  "function offerDownload(blob, name) {\n",
  "  const link = document.createElement(\"a\");\n",
  "  link.href = URL.createObjectURL(blob);\n",
  "  link.download = name;\n",
  "  link.style.display = \"none\";\n",
  "  document.body.appendChild(link);\n",
  "  link.click();\n",
  "  link.remove();\n",
  "  setTimeout(() => URL.revokeObjectURL(link.href), 10000);\n",
  "}\n",
  "\n",
  "function makeEngine(host) {\n",
  "  let graph = null;              // the live context's sound graph\n",
  "  const settings = new Map();    // channel -> its settings, for every graph\n",
  "  let masterVolume = 1;\n",
  "  const voices = new Map();      // voice -> {source, gain}\n",
  "  const sounding = new Set();    // every source started and not yet ended\n",
  "  // The beat: tempo and swing, and where the beat was at some time, so a\n",
  "  // change of tempo goes on from where the beat is.\n",
  "  let bpm = 120;\n",
  "  let swingAmount = 0;\n",
  "  let anchor = null;             // {time, beat}\n",
  "  const beats = new Map();       // watcher -> {steps, next}\n",
  "  const timers = new Map();      // timer -> {at, every}\n",
  "  let ticker = 0;\n",
  "  let frozen = null;             // the clock, while the program has paused it\n",
  "  let listening = null;          // {bins, smoothing}\n",
  "  let rendering = null;          // {id, name, seconds, commands}\n",
  "  let closed = false;\n",
  "\n",
  "  function live() {\n",
  "    const context = host.audio();\n",
  "    if (!context) return null;\n",
  "    if (graph === null || graph.context !== context) {\n",
  "      graph = soundGraph(context);\n",
  "      graph.master.gain.value = masterVolume;\n",
  "      for (const [n, s] of settings) graph.style(n, s);\n",
  "      if (listening) listen(listening.bins, listening.smoothing);\n",
  "    }\n",
  "    return graph;\n",
  "  }\n",
  "\n",
  "  function beatAt(t) {\n",
  "    return anchor === null ? 0 : anchor.beat + ((t - anchor.time) * bpm) / 60;\n",
  "  }\n",
  "\n",
  "  // When step `k` of a beat cut into `steps` steps sounds. Int -> Int -> Float\n",
  "  function stepTime(k, steps) {\n",
  "    const at = anchor.time + ((k / steps - anchor.beat) * 60) / bpm;\n",
  "    return k % 2 === 1 ? at + (swingAmount * 60) / bpm / steps : at;\n",
  "  }\n",
  "\n",
  "  function tick() {\n",
  "    if (closed) return;\n",
  "    const t = host.clock();\n",
  "    if (frozen !== null) return;\n",
  "    for (const [id, timer] of [...timers]) {\n",
  "      if (t + 0.0005 < timer.at) continue;\n",
  "      if (timer.every > 0) {\n",
  "        while (timer.at <= t + 0.0005) timer.at += timer.every;\n",
  "      } else {\n",
  "        timers.delete(id);\n",
  "      }\n",
  "      host.send({ ev: \"cb\", id, kind: \"timer\" });\n",
  "    }\n",
  "    for (const [id, watcher] of beats) {\n",
  "      for (let guard = 0; guard < 64; guard++) {\n",
  "        const at = stepTime(watcher.next, watcher.steps);\n",
  "        if (at > t + LOOKAHEAD) break;\n",
  "        host.send({ ev: \"cb\", id, kind: \"beat\",\n",
  "          reports: { beat: [watcher.next, Math.max(at, t), beatAt(t)] } });\n",
  "        watcher.next += 1;\n",
  "      }\n",
  "    }\n",
  "    if (timers.size === 0 && beats.size === 0) {\n",
  "      clearInterval(ticker);\n",
  "      ticker = 0;\n",
  "    }\n",
  "  }\n",
  "\n",
  "  function ticking() {\n",
  "    if (ticker === 0 && !closed) ticker = setInterval(tick, TICK_MS);\n",
  "  }\n",
  "\n",
  "  // Starts one sound on `g`'s context: a sample (`play` and `start`) or a\n",
  "  // tone, at `at` on that context's clock. Answers its source.\n",
  "  function sound(g, kind, sample, buffer, n, toTime) {\n",
  "    const context = g.context;\n",
  "    if (kind === \"tone\") {\n",
  "      const [frequency, at, duration, volume, pan, channel] = n;\n",
  "      const when = Math.max(context.currentTime, toTime(at));\n",
  "      const length = Math.max(0.02, duration);\n",
  "      const oscillator = context.createOscillator();\n",
  "      oscillator.type = [\"sine\", \"square\", \"triangle\", \"sawtooth\"].includes(sample) ? sample : \"sine\";\n",
  "      oscillator.frequency.value = frequency;\n",
  "      const gain = context.createGain();\n",
  "      const attack = Math.min(0.01, length / 4);\n",
  "      const release = Math.min(0.05, length / 4);\n",
  "      gain.gain.setValueAtTime(0, when);\n",
  "      gain.gain.linearRampToValueAtTime(volume, when + attack);\n",
  "      gain.gain.setValueAtTime(volume, when + length - release);\n",
  "      gain.gain.linearRampToValueAtTime(0, when + length);\n",
  "      const panner = pan !== 0 && context.createStereoPanner ? context.createStereoPanner() : null;\n",
  "      if (panner) panner.pan.value = Math.max(-1, Math.min(1, pan));\n",
  "      oscillator.connect(gain);\n",
  "      (panner ? gain.connect(panner) : gain).connect(g.channel(channel || 0).input);\n",
  "      oscillator.start(when);\n",
  "      oscillator.stop(when + length + 0.01);\n",
  "      return { source: oscillator, gain };\n",
  "    }\n",
  "    const [at, volume, rate, pan, channel, reverse, loop] = n;\n",
  "    const source = context.createBufferSource();\n",
  "    source.buffer = reverse ? reversedOf(context, buffer) : buffer;\n",
  "    source.playbackRate.value = rate > 0 ? rate : 1;\n",
  "    source.loop = !!loop;\n",
  "    const gain = context.createGain();\n",
  "    gain.gain.value = volume;\n",
  "    const panner = pan !== 0 && context.createStereoPanner ? context.createStereoPanner() : null;\n",
  "    if (panner) panner.pan.value = Math.max(-1, Math.min(1, pan));\n",
  "    source.connect(gain);\n",
  "    (panner ? gain.connect(panner) : gain).connect(g.channel(channel || 0).input);\n",
  "    source.start(Math.max(context.currentTime, toTime(at)));\n",
  "    return { source, gain };\n",
  "  }\n",
  "\n",
  "  // A sound command on the live context.\n",
  "  function playLive(cmd) {\n",
  "    const n = engineNumbers(cmd.numbers);\n",
  "    if (cmd.kind === \"tone\") {\n",
  "      host.startAudio();\n",
  "      const g = live();\n",
  "      if (!g) return;\n",
  "      const made = sound(g, \"tone\", cmd.text, null, n, host.toAudio);\n",
  "      sounding.add(made.source);\n",
  "      made.source.onended = () => sounding.delete(made.source);\n",
  "      return;\n",
  "    }\n",
  "    const sample = cmd.kind === \"play\" ? cmd.id : cmd.text;\n",
  "    host.startAudio();\n",
  "    const loading = host.sample(sample);\n",
  "    if (!loading) return;\n",
  "    const voice = cmd.kind === \"start\" ? cmd.id : null;\n",
  "    if (voice !== null) voices.set(voice, { source: null, gain: null, stopped: null });\n",
  "    loading.then((buffer) => {\n",
  "      const g = live();\n",
  "      if (buffer === null || closed || !g) return;\n",
  "      const entry = voice === null ? null : voices.get(voice);\n",
  "      if (entry && entry.stopped !== null && entry.stopped <= host.clock()) return;\n",
  "      const made = sound(g, \"sample\", sample, buffer, n, host.toAudio);\n",
  "      sounding.add(made.source);\n",
  "      made.source.onended = () => {\n",
  "        sounding.delete(made.source);\n",
  "        if (voice !== null && voices.get(voice)?.source === made.source) voices.delete(voice);\n",
  "      };\n",
  "      if (entry) {\n",
  "        entry.source = made.source;\n",
  "        entry.gain = made.gain;\n",
  "        if (entry.stopped !== null) made.source.stop(Math.max(g.context.currentTime, host.toAudio(entry.stopped)));\n",
  "        if (entry.fade) fadeVoice(entry, ...entry.fade);\n",
  "      }\n",
  "    });\n",
  "  }\n",
  "\n",
  "  function fadeVoice(entry, volume, over) {\n",
  "    const g = live();\n",
  "    if (!g || entry.gain === null) {\n",
  "      entry.fade = [volume, over];\n",
  "      return;\n",
  "    }\n",
  "    const now = g.context.currentTime;\n",
  "    const param = entry.gain.gain;\n",
  "    param.cancelScheduledValues(now);\n",
  "    param.setValueAtTime(param.value, now);\n",
  "    if (over > 0) param.linearRampToValueAtTime(volume, now + over);\n",
  "    else param.setValueAtTime(volume, now);\n",
  "  }\n",
  "\n",
  "  function stopAll() {\n",
  "    const g = live();\n",
  "    for (const source of sounding) {\n",
  "      try {\n",
  "        source.stop(g ? g.context.currentTime : 0);\n",
  "      } catch {\n",
  "        // already stopped\n",
  "      }\n",
  "    }\n",
  "    sounding.clear();\n",
  "    for (const entry of voices.values()) entry.stopped = -Infinity;\n",
  "    voices.clear();\n",
  "  }\n",
  "\n",
  "  function listen(bins, smoothing) {\n",
  "    listening = { bins, smoothing };\n",
  "    const g = graph;\n",
  "    if (!g || !g.analyser) return;\n",
  "    let size = 32;\n",
  "    while (size < bins * 2 && size < 32768) size *= 2;\n",
  "    g.analyser.fftSize = size;\n",
  "    g.analyser.smoothingTimeConstant = Math.max(0, Math.min(0.99, smoothing));\n",
  "  }\n",
  "\n",
  "  // What the page reports with an event: where the beat is, how late\n",
  "  // sound comes out, whether it is running; and with a frame, what the\n",
  "  // program listens to. Bool -> {..}\n",
  "  // The analyser's arrays, kept from frame to frame.\n",
  "  const scratch = { spectrum: new Uint8Array(0), samples: new Float32Array(0) };\n",
  "\n",
  "  function reports(withSound) {\n",
  "    const context = host.audio();\n",
  "    const t = host.clock();\n",
  "    const latency = context ? (context.outputLatency || 0) + (context.baseLatency || 0) : 0;\n",
  "    const out = { clock: [beatAt(t), latency, context && context.state === \"running\" ? 1 : 0] };\n",
  "    if (withSound && listening !== null) {\n",
  "      const g = live();\n",
  "      const bins = listening.bins;\n",
  "      const level = [0];\n",
  "      const band = new Array(bins).fill(0);\n",
  "      const wave = new Array(bins).fill(0);\n",
  "      if (g && g.analyser && g.analyser.getByteFrequencyData) {\n",
  "        const a = g.analyser;\n",
  "        if (scratch.spectrum.length !== a.frequencyBinCount) {\n",
  "          scratch.spectrum = new Uint8Array(a.frequencyBinCount);\n",
  "          scratch.samples = new Float32Array(a.fftSize);\n",
  "        }\n",
  "        const spectrum = scratch.spectrum;\n",
  "        a.getByteFrequencyData(spectrum);\n",
  "        const per = spectrum.length / bins;\n",
  "        for (let k = 0; k < bins; k++) {\n",
  "          let peak = 0;\n",
  "          for (let i = Math.floor(k * per); i < Math.max(Math.floor((k + 1) * per), Math.floor(k * per) + 1); i++) {\n",
  "            peak = Math.max(peak, spectrum[Math.min(i, spectrum.length - 1)]);\n",
  "          }\n",
  "          band[k] = Math.round((peak / 255) * 1000) / 1000;\n",
  "        }\n",
  "        const samples = scratch.samples;\n",
  "        a.getFloatTimeDomainData(samples);\n",
  "        let sum = 0;\n",
  "        for (let i = 0; i < samples.length; i++) sum += samples[i] * samples[i];\n",
  "        level[0] = Math.round(Math.min(1, Math.sqrt(sum / samples.length) * Math.SQRT2) * 1000) / 1000;\n",
  "        const step = samples.length / bins;\n",
  "        for (let k = 0; k < bins; k++) wave[k] = Math.round(samples[Math.floor(k * step)] * 1000) / 1000;\n",
  "      }\n",
  "      out.level = level;\n",
  "      out.band = band;\n",
  "      out.wave = wave;\n",
  "    }\n",
  "    return out;\n",
  "  }\n",
  "\n",
  "  // Renders what was scheduled between `render` and `render_end` offline,\n",
  "  // offers it as a WAV file and reports how long that took and how loud\n",
  "  // its loudest sample is.\n",
  "  function finishRender(job) {\n",
  "    const Offline = globalThis.OfflineAudioContext;\n",
  "    const done = (took, peak) =>\n",
  "      host.send({ ev: \"cb\", id: job.id, kind: \"rendered\", reports: { rendered: [took, peak] } });\n",
  "    if (!Offline) {\n",
  "      done(0, 0);\n",
  "      return;\n",
  "    }\n",
  "    const rate = 44100;\n",
  "    const context = new Offline(2, Math.max(1, Math.ceil(job.seconds * rate)), rate);\n",
  "    const g = soundGraph(context);\n",
  "    g.master.gain.value = masterVolume;\n",
  "    for (const [n, s] of settings) g.style(n, s);\n",
  "    const wanted = job.commands.filter((c) => c.kind !== \"tone\")\n",
  "      .map((c) => host.sample(c.kind === \"play\" ? c.id : c.text) || Promise.resolve(null));\n",
  "    Promise.all(wanted).then((buffers) => {\n",
  "      let b = 0;\n",
  "      for (const c of job.commands) {\n",
  "        const n = engineNumbers(c.numbers);\n",
  "        if (c.kind === \"tone\") {\n",
  "          sound(g, \"tone\", c.text, null, n, (t) => t);\n",
  "        } else {\n",
  "          const buffer = buffers[b++];\n",
  "          if (buffer) sound(g, \"sample\", null, buffer, n, (t) => t);\n",
  "        }\n",
  "      }\n",
  "      const started = typeof performance !== \"undefined\" ? performance.now() : Date.now();\n",
  "      return context.startRendering().then((buffer) => {\n",
  "        const took = ((typeof performance !== \"undefined\" ? performance.now() : Date.now()) - started) / 1000;\n",
  "        let peak = 0;\n",
  "        for (let k = 0; k < buffer.numberOfChannels; k++) {\n",
  "          const data = buffer.getChannelData(k);\n",
  "          for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i]));\n",
  "        }\n",
  "        offerDownload(new Blob([wavBytes(buffer)], { type: \"audio/wav\" }), job.name);\n",
  "        done(Math.round(took * 1000) / 1000, Math.round(peak * 1000) / 1000);\n",
  "      });\n",
  "    }).catch((error) => {\n",
  "      console.error(`tinyweb: rendering ${job.name} failed: ${error.message}`);\n",
  "      done(0, 0);\n",
  "    });\n",
  "  }\n",
  "\n",
  "  // An element whose `display` the program sets: a slider's row, not\n",
  "  // its input.\n",
  "  function shown(element) {\n",
  "    return element.tagName === \"INPUT\" && element.type === \"range\" ? element.parentNode : element;\n",
  "  }\n",
  "\n",
  "  function value(id, text) {\n",
  "    host.send({ ev: \"report\", reports: { [\"value.\" + id]: String(text) } });\n",
  "  }\n",
  "\n",
  "  function command(cmd) {\n",
  "    const n = engineNumbers(cmd.numbers);\n",
  "    if (rendering !== null && [\"play\", \"start\", \"tone\"].includes(cmd.kind)) {\n",
  "      rendering.commands.push(cmd);\n",
  "      return;\n",
  "    }\n",
  "    switch (cmd.kind) {\n",
  "      // --- sound ---\n",
  "      case \"play\":\n",
  "      case \"start\":\n",
  "      case \"tone\":\n",
  "        playLive(cmd);\n",
  "        break;\n",
  "      case \"stop\": {\n",
  "        const entry = voices.get(cmd.id);\n",
  "        if (!entry) break;\n",
  "        const at = n[0] || 0;\n",
  "        entry.stopped = at;\n",
  "        const g = live();\n",
  "        if (entry.source && g) entry.source.stop(Math.max(g.context.currentTime, host.toAudio(at)));\n",
  "        break;\n",
  "      }\n",
  "      case \"fade\": {\n",
  "        const entry = voices.get(cmd.id);\n",
  "        if (entry) fadeVoice(entry, n[0] ?? 0, n[1] ?? 0);\n",
  "        break;\n",
  "      }\n",
  "      case \"stop_all\":\n",
  "        stopAll();\n",
  "        break;\n",
  "      case \"master\": {\n",
  "        masterVolume = n[0] ?? 1;\n",
  "        const g = live();\n",
  "        if (g) g.master.gain.value = masterVolume;\n",
  "        break;\n",
  "      }\n",
  "      case \"channel\": {\n",
  "        const ch = Number(cmd.id) || 0;\n",
  "        const s = { volume: n[0] ?? 1, pan: n[1] ?? 0, echo: n[2] ?? 0, echoTime: n[3] ?? 0.3,\n",
  "          feedback: n[4] ?? 0.35, reverb: n[5] ?? 0, lowPass: n[6] ?? 0 };\n",
  "        settings.set(ch, s);\n",
  "        const g = live();\n",
  "        if (g) g.style(ch, s);\n",
  "        break;\n",
  "      }\n",
  "      case \"listen\":\n",
  "        listen(Math.max(1, Math.min(1024, Math.round(n[0] || 32))), n[1] ?? 0.8);\n",
  "        live();\n",
  "        break;\n",
  "      case \"tempo\": {\n",
  "        const t = host.clock();\n",
  "        anchor = anchor === null ? null : { time: t, beat: beatAt(t) };\n",
  "        bpm = Math.max(1, n[0] || 120);\n",
  "        break;\n",
  "      }\n",
  "      case \"swing\":\n",
  "        swingAmount = Math.max(0, Math.min(0.9, n[0] || 0));\n",
  "        break;\n",
  "      case \"beat\": {\n",
  "        const t = host.clock();\n",
  "        const steps = Math.max(1, Math.round(n[0] || 1));\n",
  "        if (anchor === null) anchor = { time: t + 0.05, beat: 0 };\n",
  "        // The first step not yet passed, from where the beat is.\n",
  "        // `+ 0` makes a -0 at the very start a 0: a step is a whole number.\n",
  "        let next = Math.ceil(beatAt(t) * steps - 1e-9) + 0;\n",
  "        while (stepTime(next, steps) < t) next += 1;\n",
  "        beats.set(cmd.id, { steps, next });\n",
  "        ticking();\n",
  "        break;\n",
  "      }\n",
  "      case \"beat_stop\":\n",
  "        beats.delete(cmd.id);\n",
  "        break;\n",
  "      case \"audio\": {\n",
  "        const context = host.audio();\n",
  "        if (cmd.text === \"pause\" && frozen === null) {\n",
  "          frozen = host.clock();\n",
  "          if (context && context.state === \"running\") context.suspend().catch(() => {});\n",
  "        } else if (cmd.text === \"resume\" && frozen !== null) {\n",
  "          const at = frozen;\n",
  "          if (context) {\n",
  "            // A page closed meanwhile closes its context, and the\n",
  "            // resume() is then refused: the run is over.\n",
  "            context.resume().then(() => {\n",
  "              host.thaw(at);\n",
  "              frozen = null;\n",
  "            }, () => {});\n",
  "          } else {\n",
  "            host.thaw(at);\n",
  "            frozen = null;\n",
  "          }\n",
  "        }\n",
  "        break;\n",
  "      }\n",
  "      case \"render\":\n",
  "        rendering = { id: cmd.id, name: cmd.text, seconds: n[0] || 1, commands: [] };\n",
  "        break;\n",
  "      case \"render_end\":\n",
  "        if (rendering !== null) {\n",
  "          const job = rendering;\n",
  "          rendering = null;\n",
  "          finishRender(job);\n",
  "        }\n",
  "        break;\n",
  "      // --- timers ---\n",
  "      case \"after\":\n",
  "      case \"every\": {\n",
  "        const seconds = Math.max(0, n[0] || 0);\n",
  "        timers.set(cmd.id, { at: host.clock() + seconds, every: cmd.kind === \"every\" ? Math.max(0.001, seconds) : 0 });\n",
  "        ticking();\n",
  "        break;\n",
  "      }\n",
  "      case \"cancel\":\n",
  "        timers.delete(cmd.id);\n",
  "        beats.delete(cmd.id);\n",
  "        break;\n",
  "      // --- changing what is on the page ---\n",
  "      case \"set_text\": {\n",
  "        const element = host.element(cmd.id);\n",
  "        if (!element) break;\n",
  "        if (element.tagName === \"INPUT\" || element.tagName === \"TEXTAREA\") element.value = cmd.text;\n",
  "        else element.textContent = cmd.text;\n",
  "        break;\n",
  "      }\n",
  "      case \"visible\": {\n",
  "        const element = host.element(cmd.id);\n",
  "        if (element) shown(element).style.display = n[0] ? \"\" : \"none\";\n",
  "        break;\n",
  "      }\n",
  "      case \"enabled\": {\n",
  "        const element = host.element(cmd.id);\n",
  "        if (element) element.disabled = !n[0];\n",
  "        break;\n",
  "      }\n",
  "      case \"remove\": {\n",
  "        const element = host.element(cmd.id);\n",
  "        if (element) shown(element).remove();\n",
  "        host.forget(cmd.id);\n",
  "        break;\n",
  "      }\n",
  "      case \"text_area\": {\n",
  "        const area = document.createElement(\"textarea\");\n",
  "        area.setAttribute(\"data-tinyweb-id\", String(cmd.id));\n",
  "        area.value = cmd.text;\n",
  "        area.rows = Math.max(1, Math.round(n[0] || 4));\n",
  "        area.cols = Math.max(1, Math.round(n[1] || 40));\n",
  "        area.addEventListener(\"input\", () => {\n",
  "          host.send({ ev: \"cb\", id: cmd.id, kind: \"change\", reports: { [\"value.\" + cmd.id]: area.value } });\n",
  "        });\n",
  "        host.remember(cmd.id, area);\n",
  "        host.place(area);\n",
  "        break;\n",
  "      }\n",
  "      case \"load_bitmap\":\n",
  "        readPicture(cmd.text, import.meta.url, (pixels) =>\n",
  "          host.send({ ev: \"cb\", id: cmd.id, kind: \"loaded\", reports: { [\"pixels.\" + cmd.id]: pixels } }));\n",
  "        break;\n",
  "      case \"file_button\": {\n",
  "        const button = document.createElement(\"button\");\n",
  "        button.setAttribute(\"data-tinyweb-id\", String(cmd.id));\n",
  "        button.textContent = cmd.text;\n",
  "        const input = document.createElement(\"input\");\n",
  "        input.type = \"file\";\n",
  "        input.style.display = \"none\";\n",
  "        button.addEventListener(\"click\", () => {\n",
  "          host.startAudio();\n",
  "          input.click();\n",
  "        });\n",
  "        // The input is inside the button: its own click is not the button's.\n",
  "        input.addEventListener(\"click\", (event) => event.stopPropagation());\n",
  "        input.addEventListener(\"change\", () => {\n",
  "          const file = input.files && input.files[0];\n",
  "          if (!file) return;\n",
  "          file.arrayBuffer().then((bytes) => {\n",
  "            if (/^audio\\//.test(file.type) || /\\.(wav|mp3|ogg|m4a|flac|aac)$/i.test(file.name)) {\n",
  "              const decoder = new OfflineAudioContext(1, 1, 44100);\n",
  "              const loading = decoder.decodeAudioData(bytes).catch(() => null);\n",
  "              host.addSample(cmd.id, loading);\n",
  "              loading.then(() => host.send({ ev: \"cb\", id: cmd.id, kind: \"loaded\",\n",
  "                reports: { file: file.name, [\"file.text\"]: \"\" } }));\n",
  "            } else {\n",
  "              const text = new TextDecoder().decode(bytes);\n",
  "              host.send({ ev: \"cb\", id: cmd.id, kind: \"loaded\", reports: { file: file.name, [\"file.text\"]: text } });\n",
  "            }\n",
  "          });\n",
  "        });\n",
  "        host.remember(cmd.id, button);\n",
  "        host.place(button);\n",
  "        button.appendChild(input);\n",
  "        break;\n",
  "      }\n",
  "      case \"cursor\": {\n",
  "        const target = cmd.id === \"\" ? document.body : host.canvas(cmd.id)?.element;\n",
  "        if (target) target.style.cursor = cmd.text || \"auto\";\n",
  "        break;\n",
  "      }\n",
  "      case \"save_canvas\": {\n",
  "        const entry = host.canvas(cmd.id);\n",
  "        if (!entry || !entry.element.toBlob) break;\n",
  "        const out = document.createElement(\"canvas\");\n",
  "        out.width = entry.width;\n",
  "        out.height = entry.height;\n",
  "        const g = out.getContext(\"2d\");\n",
  "        g.fillStyle = \"#ffffff\";\n",
  "        g.fillRect(0, 0, out.width, out.height);\n",
  "        g.drawImage(entry.element, 0, 0, out.width, out.height);\n",
  "        out.toBlob((blob) => { if (blob) offerDownload(blob, cmd.text); }, \"image/png\");\n",
  "        break;\n",
  "      }\n",
  "      case \"download\":\n",
  "        offerDownload(new Blob([cmd.text], { type: \"text/plain\" }), cmd.id);\n",
  "        break;\n",
  "    }\n",
  "  }\n",
  "\n",
  "  return {\n",
  "    command,\n",
  "    reports,\n",
  "    value,\n",
  "    // The clock while the program has paused it, or null.\n",
  "    frozen: () => frozen,\n",
  "    // Whether a command needs sound, which may need the splash screen first.\n",
  "    sounds: (cmd) => [\"play\", \"start\", \"tone\"].includes(cmd.kind),\n",
  "    close() {\n",
  "      closed = true;\n",
  "      clearInterval(ticker);\n",
  "      ticker = 0;\n",
  "      stopAll();\n",
  "    },\n",
  "  };\n",
  "}\n",
  "// END tinyweb style\n",
  "\n",
  "// Mounts a tinyweb page in `element` and answers {receive, setHidden,\n",
  "// freeze, close}: `receive(commands)` carries out a batch of commands,\n",
  "// and `send(event)` is how the page reports one. `setHidden(true)` holds\n",
  "// the page while the reader cannot see it -- the website showing another\n",
  "// of its sections -- and `setHidden(false)` lets it go on. `standalone` is true where the page is\n",
  "// the whole document, which is where a key press is listened for; a\n",
  "// page inside another (a notebook cell) listens on `element`, which\n",
  "// takes the focus when clicked. `activated` is true where the reader\n",
  "// started the program with a click or a key, as in the playground and\n",
  "// a notebook, and the page then never shows the splash screen.\n",
  "// `silent` is true where the page is only a picture of what a program\n",
  "// drew -- a notebook's result diff -- and never makes a sound.\n",
  "export function mountPage(element, sendEvent,\n",
  "                          { standalone = false, activated = false, silent = false } = {}) {\n",
  "  const box = document.createElement(\"div\");\n",
  "  box.className = \"tinyweb-page\";\n",
  "  box.style.cssText =\n",
  "    \"display:flex;flex-direction:column;align-items:flex-start;outline:none\";\n",
  "  element.appendChild(box);\n",
  "  const look = styled(element, box);\n",
  "\n",
  "  const canvases = new Map();\n",
  "  const labels = new Map();\n",
  "  const samples = new Map();\n",
  "  const pictures = new Map();\n",
  "  // What `set_checked` and `set_value` change, by identifier, and each\n",
  "  // group of radio buttons.\n",
  "  const checks = new Map();\n",
  "  const values = new Map();\n",
  "  const groups = new Map();\n",
  "  const bitmaps = new Map();\n",
  "  // Where an element made now goes: the page, or a row it was put inside.\n",
  "  const rows = new Map();\n",
  "  let parent = box;\n",
  "  // The keys held down, reported again as released when the page loses\n",
  "  // the focus.\n",
  "  const heldKeys = new Set();\n",
  "  let start = now();\n",
  "  let audio = null;\n",
  "  let offset = 0;\n",
  "  let frameWanted = false;\n",
  "  let frameWaiting = false;\n",
  "  let frameRequest = 0;\n",
  "  let closed = false;\n",
  "  // Sound, the beat, timers and page changes (the `cmd` commands).\n",
  "  let engine = null;\n",
  "  // Inside another page the keys go to the element the page is mounted\n",
  "  // in, which takes the focus when anything in it is clicked; that page\n",
  "  // shows the focus (:focus-within).\n",
  "  const keyTarget = standalone ? window : element;\n",
  "  let keysWanted = false;\n",
  "  // The splash screen: what it says, whether it has been shown (or is\n",
  "  // not needed), and while it is shown the element, the commands held\n",
  "  // until it is dismissed, and the clock where it stopped.\n",
  "  let splashText = SPLASH_TEXT;\n",
  "  let splashDone = activated;\n",
  "  let splash = null;\n",
  "  let held = null;\n",
  "  let heldClock = 0;\n",
  "  let heldAt = 0;\n",
  "  // The picture the held commands wait for, and the events the reader\n",
  "  // caused while they waited for it.\n",
  "  let waitingFor = null;\n",
  "  let deferred = [];\n",
  "  // tinyweb's `sdelay`: where the last one ends on the page's clock (null\n",
  "  // before the first), the one to answer and when, and once it is\n",
  "  // answered, what the program does next that is not a sound, held until\n",
  "  // the end -- a sound is started at the end instead (`timed`). The\n",
  "  // interval looks at the clock while one of them waits.\n",
  "  let sdelayEnd = null;\n",
  "  let answering = null;\n",
  "  let paced = null;\n",
  "  let pacer = 0;\n",
  "\n",
  "  let focusable = false;    // whether mounting made `element` focusable\n",
  "  // Whether the page is out of sight (`setHidden`): held like the splash\n",
  "  // screen holds it, with its sound suspended.\n",
  "  let away = false;\n",
  "\n",
  "  function takeFocus(event) {\n",
  "    // A slider keeps the focus for its arrow keys.\n",
  "    if (!event.target.closest(\"input\")) element.focus({ preventScroll: true });\n",
  "  }\n",
  "\n",
  "  if (!standalone) {\n",
  "    focusable = element.tabIndex < 0;\n",
  "    if (focusable) element.tabIndex = 0;\n",
  "    element.addEventListener(\"click\", takeFocus);\n",
  "  }\n",
  "\n",
  "  // The page's clock: the audio clock once sound has started, and until\n",
  "  // then the seconds since the page was mounted. `offset` joins the two,\n",
  "  // so the clock never goes back.\n",
  "  function running() {\n",
  "    return audio !== null && audio.state === \"running\";\n",
  "  }\n",
  "\n",
  "  function clockNow() {\n",
  "    if (held !== null) return heldClock;\n",
  "    const paused = engine === null ? null : engine.frozen();\n",
  "    if (paused !== null) return paused;\n",
  "    return running() ? audio.currentTime + offset : (now() - start) / 1000;\n",
  "  }\n",
  "\n",
  "  // Every event carries where the beat is and how late sound comes out,\n",
  "  // and a frame what the program listens to.\n",
  "  function report(event) {\n",
  "    if (closed) return;\n",
  "    if (held !== null) {\n",
  "      if (splash === null) deferred.push(event);\n",
  "      return;\n",
  "    }\n",
  "    const reports = { ...engine.reports(event.ev === \"frame\"), ...(event.reports || {}) };\n",
  "    sendEvent({ ...event, t: clockNow(), running: running(), reports });\n",
  "  }\n",
  "\n",
  "  // Whether a sound now would need the splash screen first.\n",
  "  function splashWanted() {\n",
  "    return !splashDone && splashText !== \"\" && !running() && !readerActive();\n",
  "  }\n",
  "\n",
  "  // Shows the splash screen and holds what comes after it: the commands,\n",
  "  // the frames and the clock.\n",
  "  function showSplash() {\n",
  "    splashDone = true;\n",
  "    heldClock = clockNow();\n",
  "    heldAt = now();\n",
  "    held = [];\n",
  "    splash = splashScreen(splashText);\n",
  "    splash.addEventListener(\"click\", dismissSplash);\n",
  "    window.addEventListener(\"keydown\", dismissSplash, true);\n",
  "    document.body.appendChild(splash);\n",
  "  }\n",
  "\n",
  "  // The reader's click or key: the splash screen goes, sound starts, the\n",
  "  // clock goes on from where it stopped, and what was held is carried out.\n",
  "  function dismissSplash(event) {\n",
  "    if (splash === null) return;\n",
  "    event?.preventDefault?.();\n",
  "    event?.stopImmediatePropagation?.();\n",
  "    window.removeEventListener(\"keydown\", dismissSplash, true);\n",
  "    splash.remove();\n",
  "    splash = null;\n",
  "    startAudio();\n",
  "    release();\n",
  "  }\n",
  "\n",
  "  // Holds what comes after a picture still loading, until it has loaded\n",
  "  // or failed: the commands, the frames, the events and the clock.\n",
  "  // Picture -> ()\n",
  "  function waitFor(picture) {\n",
  "    if (held === null) {\n",
  "      heldClock = clockNow();\n",
  "      heldAt = now();\n",
  "      held = [];\n",
  "    }\n",
  "    waitingFor = picture;\n",
  "    picture.settled.push(() => {\n",
  "      waitingFor = null;\n",
  "      release();\n",
  "    });\n",
  "  }\n",
  "\n",
  "  // Carries out what was held once nothing holds it any more, then sends\n",
  "  // the events that waited with it. ()\n",
  "  function release() {\n",
  "    if (held === null || splash !== null || waitingFor !== null || away) return;\n",
  "    start += now() - heldAt;\n",
  "    const pending = held;\n",
  "    held = null;\n",
  "    for (const command of pending) take(command);\n",
  "    if (held !== null) return;\n",
  "    const events = deferred;\n",
  "    deferred = [];\n",
  "    for (const event of events) report(event);\n",
  "  }\n",
  "\n",
  "  // Holds the page while it is out of sight, as the splash screen does --\n",
  "  // the commands, the frames, the events and the clock -- and suspends its\n",
  "  // sound; shown again, the clock goes on from where it stopped, the sound\n",
  "  // too unless the program paused it itself, and what was held is carried\n",
  "  // out. Bool -> ()\n",
  "  function setHidden(hidden) {\n",
  "    if (closed || hidden === away) return;\n",
  "    away = hidden;\n",
  "    if (hidden) {\n",
  "      if (held === null) {\n",
  "        heldClock = clockNow();\n",
  "        held = [];\n",
  "      }\n",
  "      if (audio !== null && audio.state === \"running\") audio.suspend().catch(() => {});\n",
  "      return;\n",
  "    }\n",
  "    // From where the clock was held, whatever held it first; the splash\n",
  "    // screen, if it is still shown, holds it on from here.\n",
  "    start = now() - heldClock * 1000;\n",
  "    heldAt = now();\n",
  "    if (audio !== null && audio.state === \"suspended\" && engine.frozen() === null) {\n",
  "      audio.resume().catch(() => {});\n",
  "    }\n",
  "    release();\n",
  "  }\n",
  "\n",
  "  // Carries out a command, or holds it while something holds the page,\n",
  "  // or until the `sdelay` before it has ended. Command -> ()\n",
  "  function take(command) {\n",
  "    if (held !== null) held.push(command);\n",
  "    else if (paced !== null && !sound(command)) paced.push(command);\n",
  "    else carryOut(paced !== null ? timed(command) : command);\n",
  "  }\n",
  "\n",
  "  // `sdelay seconds`, reached in the program's order: it ends `seconds`\n",
  "  // after the last one ended -- or after now, for the first, and where\n",
  "  // that end has passed already, so a program that fell behind starts\n",
  "  // again from now rather than catching up. The program waits until the\n",
  "  // page answers it. Command -> ()\n",
  "  function sdelay(command) {\n",
  "    const t = clockNow();\n",
  "    const seconds = Math.max(0, Number(command.seconds) || 0);\n",
  "    sdelayEnd = sdelayEnd === null ? t + seconds : Math.max(sdelayEnd + seconds, t);\n",
  "    answering = { id: command.id, at: sdelayEnd - SDELAY_LEAD };\n",
  "    pace();\n",
  "  }\n",
  "\n",
  "  // Looks at the clock for the `sdelay` waiting: answers it a little\n",
  "  // before its end, and carries out what was held after it once the end\n",
  "  // has come. ()\n",
  "  function pace() {\n",
  "    if (closed) return;\n",
  "    const t = clockNow();\n",
  "    if (answering !== null && t >= answering.at) {\n",
  "      const { id } = answering;\n",
  "      answering = null;\n",
  "      if (paced === null) paced = [];\n",
  "      report({ ev: \"sdelay\", id });\n",
  "    }\n",
  "    if (paced !== null && answering === null && t >= sdelayEnd) {\n",
  "      const pending = paced;\n",
  "      paced = null;\n",
  "      for (const command of pending) take(command);\n",
  "    }\n",
  "    const needed = answering !== null || paced !== null;\n",
  "    if (needed && pacer === 0) pacer = setInterval(pace, SDELAY_TICK_MS);\n",
  "    else if (!needed && pacer !== 0) {\n",
  "      clearInterval(pacer);\n",
  "      pacer = 0;\n",
  "    }\n",
  "  }\n",
  "\n",
  "  // Whether a command starts a sound. Command -> Bool\n",
  "  function sound(command) {\n",
  "    return command.op === \"cmd\" && engine.sounds(command);\n",
  "  }\n",
  "\n",
  "  // A sound the program starts after an `sdelay`, with no time of its\n",
  "  // own, starts where the `sdelay` ends, exactly. Command -> Command\n",
  "  function timed(command) {\n",
  "    if (sdelayEnd === null || !sound(command)) return command;\n",
  "    const n = String(command.numbers ?? \"\").trim().split(/\\s+/);\n",
  "    const k = command.kind === \"tone\" ? 1 : 0;\n",
  "    if (n.length <= k || Number(n[k]) !== 0) return command;\n",
  "    n[k] = String(sdelayEnd);\n",
  "    return { ...command, numbers: n.join(\" \") };\n",
  "  }\n",
  "\n",
  "  // Sound may start only after the reader did something, so every\n",
  "  // gesture is a chance to start it.\n",
  "  function startAudio() {\n",
  "    if (silent) return;\n",
  "    if (audio === null) {\n",
  "      const Context = globalThis.AudioContext || globalThis.webkitAudioContext;\n",
  "      if (!Context) return;\n",
  "      const before = clockNow();\n",
  "      audio = new Context();\n",
  "      offset = before - audio.currentTime;\n",
  "      audio.onstatechange = () => {\n",
  "        if (audio.state !== \"running\") return;\n",
  "        const paused = engine.frozen();\n",
  "        offset = (paused !== null ? paused : (now() - start) / 1000) - audio.currentTime;\n",
  "      };\n",
  "    }\n",
  "    // Refused where the page closes meanwhile, which is no matter.\n",
  "    if (audio.state === \"suspended\") audio.resume().catch(() => {});\n",
  "  }\n",
  "\n",
  "  box.addEventListener(\"pointerdown\", startAudio);\n",
  "\n",
  "  engine = makeEngine({\n",
  "    audio: () => audio,\n",
  "    startAudio,\n",
  "    clock: clockNow,\n",
  "    toAudio: (t) => t - offset,\n",
  "    thaw: (t) => {\n",
  "      start = now() - t * 1000;\n",
  "      if (running()) offset = t - audio.currentTime;\n",
  "    },\n",
  "    sample: (id) => samples.get(id),\n",
  "    addSample: (id, loading) => samples.set(id, loading),\n",
  "    element: (id) => look.elements.get(id),\n",
  "    forget: (id) => look.elements.delete(id),\n",
  "    remember: (id, made) => remember(look, id, made),\n",
  "    place: (made) => parent.appendChild(made),\n",
  "    canvas: (id) => canvases.get(id),\n",
  "    send: (event) => report(event),\n",
  "  });\n",
  "\n",
  "  function onKey(event) {\n",
  "    if (splash !== null) {\n",
  "      dismissSplash(event);\n",
  "      return;\n",
  "    }\n",
  "    startAudio();\n",
  "    if (!keysWanted || typedInField(event)) return;\n",
  "    // Arrows and the space bar move the program's world, not the page.\n",
  "    if (standalone && [\"ArrowUp\", \"ArrowDown\", \"ArrowLeft\", \"ArrowRight\", \" \"].includes(event.key)) {\n",
  "      event.preventDefault?.();\n",
  "    }\n",
  "    heldKeys.add(event.key);\n",
  "    report({ ev: \"key\", key: event.key });\n",
  "  }\n",
  "  keyTarget.addEventListener(\"keydown\", onKey);\n",
  "\n",
  "  function onKeyUp(event) {\n",
  "    if (!keysWanted) return;\n",
  "    if (heldKeys.delete(event.key)) report({ ev: \"key_up\", key: event.key });\n",
  "  }\n",
  "  keyTarget.addEventListener(\"keyup\", onKeyUp);\n",
  "\n",
  "  // A key released while the page did not have the focus is never\n",
  "  // reported, so leaving the page lets go of every key.\n",
  "  function onBlur() {\n",
  "    for (const key of heldKeys) report({ ev: \"key_up\", key });\n",
  "    heldKeys.clear();\n",
  "  }\n",
  "  window.addEventListener(\"blur\", onBlur);\n",
  "\n",
  "  function loadSample(name) {\n",
  "    const decoder = new OfflineAudioContext(1, 1, 44100);\n",
  "    const fetchArray = (url) =>\n",
  "      fetch(url).then((response) => {\n",
  "        if (!response.ok) throw new Error(`${name}: ${response.status}`);\n",
  "        return response.arrayBuffer();\n",
  "      });\n",
  "    return fetchArray(new URL(name, document.baseURI))\n",
  "      .catch(() => fetchArray(new URL(\"tinyweb_assets/\" + name, import.meta.url)))\n",
  "      .then((bytes) => decoder.decodeAudioData(bytes))\n",
  "      .catch((error) => {\n",
  "        console.error(`tinyweb: cannot load the sample ${name}: ${error.message}`);\n",
  "        return null;\n",
  "      });\n",
  "  }\n",
  "\n",
  "  function frame() {\n",
  "    if (closed) return;\n",
  "    if (!frameWaiting && held === null) {\n",
  "      frameWaiting = true;\n",
  "      report({ ev: \"frame\" });\n",
  "    }\n",
  "    if (answering !== null || paced !== null) pace();\n",
  "    frameRequest = requestAnimationFrame(frame);\n",
  "  }\n",
  "\n",
  "  function newCanvas({ id, width, height }) {\n",
  "    const element = document.createElement(\"canvas\");\n",
  "    element.setAttribute(\"data-tinyweb-id\", String(id));\n",
  "    const ratio = globalThis.devicePixelRatio || 1;\n",
  "    element.width = Math.round(width * ratio);\n",
  "    element.height = Math.round(height * ratio);\n",
  "    element.style.width = width + \"px\";\n",
  "    element.style.height = height + \"px\";\n",
  "    element.style.background = \"#ffffff\";\n",
  "    const context = element.getContext(\"2d\");\n",
  "    context.scale(ratio, ratio);\n",
  "    plainLines(context);\n",
  "    const entry = {\n",
  "      element, context, width, height, mouse: false, pointer: false, ratio, depth: 0,\n",
  "      gradients: new Map(),\n",
  "    };\n",
  "    canvases.set(id, entry);\n",
  "    remember(look, id, element);\n",
  "    const where = (event) => {\n",
  "      const bounds = element.getBoundingClientRect();\n",
  "      return {\n",
  "        x: Math.round(((event.clientX - bounds.left) * width) / bounds.width),\n",
  "        y: Math.round(((event.clientY - bounds.top) * height) / bounds.height),\n",
  "      };\n",
  "    };\n",
  "    element.addEventListener(\"click\", (event) => {\n",
  "      if (entry.mouse) report({ ev: \"mouse\", c: id, ...where(event) });\n",
  "    });\n",
  "    // A browser reports a move at most once a frame already.\n",
  "    element.addEventListener(\"pointerdown\", (event) => {\n",
  "      if (!entry.pointer) return;\n",
  "      capture(element, event);\n",
  "      startAudio();\n",
  "      report({ ev: \"press\", c: id, ...where(event) });\n",
  "    });\n",
  "    element.addEventListener(\"pointerup\", (event) => {\n",
  "      if (entry.pointer) report({ ev: \"release\", c: id, ...where(event) });\n",
  "    });\n",
  "    element.addEventListener(\"pointermove\", (event) => {\n",
  "      if (entry.pointer) report({ ev: \"move\", c: id, ...where(event) });\n",
  "    });\n",
  "    element.addEventListener(\"contextmenu\", (event) => {\n",
  "      if (entry.pointer) event.preventDefault?.();\n",
  "    });\n",
  "    element.style.touchAction = \"none\";\n",
  "    parent.appendChild(element);\n",
  "  }\n",
  "\n",
  "  function draw(c, paint) {\n",
  "    const entry = canvases.get(c);\n",
  "    if (entry) paint(entry.context, entry);\n",
  "  }\n",
  "\n",
  "  function carryOut(command) {\n",
  "    switch (command.op) {\n",
  "      case \"canvas\":\n",
  "        newCanvas(command);\n",
  "        break;\n",
  "      case \"clear\":\n",
  "        draw(command.c, (g, entry) => {\n",
  "          freshState(g, entry);\n",
  "          g.fillStyle = paint(g, entry, command.color);\n",
  "          g.fillRect(0, 0, entry.width, entry.height);\n",
  "        });\n",
  "        break;\n",
  "      case \"shape\":\n",
  "        draw(command.c, (g, entry) => drawShape(g, entry, command.kind, command.numbers,\n",
  "          command.color, command.outline, command.width, command.alpha));\n",
  "        break;\n",
  "      case \"text\":\n",
  "        draw(command.c, (g, entry) => drawText(g, entry, command.x, command.y, command.words,\n",
  "          command.color, command.size, command.font, command.align, command.baseline,\n",
  "          command.bold, command.outline, command.outline_width, command.alpha));\n",
  "        break;\n",
  "      case \"measure\": {\n",
  "        // Answered once the code that asked has finished, as any event is.\n",
  "        const width = textWidth(command.words, command.size, command.font, command.bold);\n",
  "        queueMicrotask(() => report({ ev: \"measured\", id: command.id, width }));\n",
  "        break;\n",
  "      }\n",
  "      case \"bitmap\": {\n",
  "        let surface = bitmaps.get(command.id);\n",
  "        if (!surface || surface.width !== command.width || surface.height !== command.height) {\n",
  "          surface = bitmapSurface(command.width, command.height);\n",
  "          bitmaps.set(command.id, surface);\n",
  "        }\n",
  "        const [rx, ry, rw, rh] = command.rect;\n",
  "        updateSurface(surface, rx, ry, rw, rh, command.data);\n",
  "        draw(command.c, (g) => drawSurface(g, surface, command.x, command.y, command.scale));\n",
  "        break;\n",
  "      }\n",
  "      case \"state\":\n",
  "        draw(command.c, (g, entry) => canvasState(g, entry, command.kind, command.value,\n",
  "          command.numbers));\n",
  "        break;\n",
  "      case \"image_load\":\n",
  "        pictures.set(command.id, loadPicture(command.name, import.meta.url));\n",
  "        break;\n",
  "      case \"image\": {\n",
  "        const picture = pictures.get(command.picture);\n",
  "        if (picture && picture.loading) {\n",
  "          waitFor(picture);\n",
  "          held.push(command);\n",
  "          break;\n",
  "        }\n",
  "        draw(command.c, (g) => drawPicture(g, picture, command.x,\n",
  "          command.y, command.width, command.height, command.alpha));\n",
  "        break;\n",
  "      }\n",
  "      case \"checkbox\": {\n",
  "        const { row, input } = choiceRow(\"checkbox\", command.id, command.title, command.checked);\n",
  "        input.addEventListener(\"change\", () => {\n",
  "          startAudio();\n",
  "          report({ ev: \"check\", id: command.id, checked: input.checked,\n",
  "            reports: { [\"value.\" + command.id]: String(input.checked) } });\n",
  "        });\n",
  "        checks.set(command.id, (on) => { input.checked = on; });\n",
  "        remember(look, command.id, input);\n",
  "        parent.appendChild(row);\n",
  "        break;\n",
  "      }\n",
  "      case \"radio\": {\n",
  "        const members = groups.get(command.group) || [];\n",
  "        groups.set(command.group, members);\n",
  "        const first = members.length === 0;\n",
  "        const { row, input } = choiceRow(\"radio\", command.id, command.title,\n",
  "          command.chosen || first);\n",
  "        input.name = `${look.name}:${command.group}`;\n",
  "        const choose = () => {\n",
  "          for (const other of members) other.checked = other === input;\n",
  "        };\n",
  "        if (command.chosen) choose();\n",
  "        members.push(input);\n",
  "        input.addEventListener(\"change\", () => {\n",
  "          startAudio();\n",
  "          choose();\n",
  "          report({ ev: \"pick\", id: command.id });\n",
  "        });\n",
  "        checks.set(command.id, (on) => {\n",
  "          if (on) choose();\n",
  "          else input.checked = false;\n",
  "        });\n",
  "        remember(look, command.id, input);\n",
  "        parent.appendChild(row);\n",
  "        break;\n",
  "      }\n",
  "      case \"choice\": {\n",
  "        const select = choiceElement(command.id, command.options, command.chosen);\n",
  "        select.addEventListener(\"change\", () => {\n",
  "          startAudio();\n",
  "          report({ ev: \"choose\", id: command.id, value: Number(select.value),\n",
  "            reports: { [\"value.\" + command.id]: select.value } });\n",
  "        });\n",
  "        values.set(command.id, (value) => { select.value = String(value); });\n",
  "        remember(look, command.id, select);\n",
  "        parent.appendChild(select);\n",
  "        break;\n",
  "      }\n",
  "      case \"text_input\": {\n",
  "        const input = textInputElement(command.id, command.placeholder);\n",
  "        input.addEventListener(\"input\", () => engine.value(command.id, input.value));\n",
  "        input.addEventListener(\"keydown\", (event) => {\n",
  "          if (event.key === \"Enter\") {\n",
  "            startAudio();\n",
  "            report({ ev: \"enter\", id: command.id, text: input.value });\n",
  "          }\n",
  "        });\n",
  "        remember(look, command.id, input);\n",
  "        parent.appendChild(input);\n",
  "        break;\n",
  "      }\n",
  "      case \"number\": {\n",
  "        const input = numberElement(command.id, command.low, command.high, command.value);\n",
  "        input.addEventListener(\"change\", () => {\n",
  "          startAudio();\n",
  "          report({ ev: \"slide\", id: command.id, value: Number(input.value),\n",
  "            reports: { [\"value.\" + command.id]: input.value } });\n",
  "        });\n",
  "        values.set(command.id, (value) => { input.value = String(value); });\n",
  "        remember(look, command.id, input);\n",
  "        parent.appendChild(input);\n",
  "        break;\n",
  "      }\n",
  "      case \"set_checked\":\n",
  "        if (checks.has(command.id)) checks.get(command.id)(command.checked);\n",
  "        break;\n",
  "      case \"set_value\":\n",
  "        if (values.has(command.id)) values.get(command.id)(command.value);\n",
  "        break;\n",
  "      case \"button\": {\n",
  "        const button = document.createElement(\"button\");\n",
  "        button.setAttribute(\"data-tinyweb-id\", String(command.id));\n",
  "        button.textContent = command.title;\n",
  "        button.addEventListener(\"click\", () => {\n",
  "          startAudio();\n",
  "          report({ ev: \"click\", id: command.id });\n",
  "        });\n",
  "        remember(look, command.id, button);\n",
  "        parent.appendChild(button);\n",
  "        break;\n",
  "      }\n",
  "      case \"label\": {\n",
  "        const text = document.createElement(\"div\");\n",
  "        text.className = \"tinyweb-label\";\n",
  "        text.setAttribute(\"data-tinyweb-id\", String(command.id));\n",
  "        text.textContent = command.text;\n",
  "        labels.set(command.id, text);\n",
  "        remember(look, command.id, text);\n",
  "        parent.appendChild(text);\n",
  "        break;\n",
  "      }\n",
  "      case \"row\":\n",
  "      case \"column\": {\n",
  "        const row = rowElement(command.id, command.op === \"row\");\n",
  "        rows.set(command.id, row);\n",
  "        remember(look, command.id, row);\n",
  "        parent.appendChild(row);\n",
  "        break;\n",
  "      }\n",
  "      case \"inside\":\n",
  "        parent = rows.get(command.id) || box;\n",
  "        break;\n",
  "      case \"outside\":\n",
  "        parent = box;\n",
  "        break;\n",
  "      case \"set_label\":\n",
  "        // A label's text, or a button's title.\n",
  "        if (labels.has(command.id)) labels.get(command.id).textContent = command.text;\n",
  "        else if (look.elements.get(command.id)?.tagName === \"BUTTON\") {\n",
  "          look.elements.get(command.id).textContent = command.text;\n",
  "        }\n",
  "        break;\n",
  "      case \"slider\": {\n",
  "        const row = document.createElement(\"label\");\n",
  "        row.className = \"tinyweb-slider\";\n",
  "        row.style.cssText = \"display:flex;align-items:center;gap:8px\";\n",
  "        const input = document.createElement(\"input\");\n",
  "        input.type = \"range\";\n",
  "        input.setAttribute(\"data-tinyweb-id\", String(command.id));\n",
  "        input.min = String(command.low);\n",
  "        input.max = String(command.high);\n",
  "        input.value = String(command.value);\n",
  "        const shown = document.createElement(\"span\");\n",
  "        shown.textContent = input.value;\n",
  "        input.addEventListener(\"input\", () => {\n",
  "          shown.textContent = input.value;\n",
  "          report({ ev: \"slide\", id: command.id, value: Number(input.value),\n",
  "            reports: { [\"value.\" + command.id]: input.value } });\n",
  "        });\n",
  "        row.append(input, shown);\n",
  "        values.set(command.id, (value) => {\n",
  "          input.value = String(value);\n",
  "          shown.textContent = input.value;\n",
  "        });\n",
  "        remember(look, command.id, input);\n",
  "        parent.appendChild(row);\n",
  "        break;\n",
  "      }\n",
  "      case \"style\":\n",
  "        applyStyle(look, command.id, command.kind, command.prop, command.value);\n",
  "        break;\n",
  "      case \"load\":\n",
  "        samples.set(command.id, loadSample(command.name));\n",
  "        break;\n",
  "      case \"cmd\":\n",
  "        if (engine.sounds(command) && splashWanted()) {\n",
  "          showSplash();\n",
  "          held.push(command);\n",
  "        } else {\n",
  "          engine.command(command);\n",
  "        }\n",
  "        break;\n",
  "      case \"splash\":\n",
  "        if (splashWanted()) showSplash();\n",
  "        break;\n",
  "      case \"splash_text\":\n",
  "        splashText = command.text;\n",
  "        break;\n",
  "      case \"on_frame\":\n",
  "        if (!frameWanted) {\n",
  "          frameWanted = true;\n",
  "          frameRequest = requestAnimationFrame(frame);\n",
  "        }\n",
  "        break;\n",
  "      case \"frame_done\":\n",
  "        frameWaiting = false;\n",
  "        break;\n",
  "      case \"sdelay\":\n",
  "        sdelay(command);\n",
  "        break;\n",
  "      case \"on_mouse\": {\n",
  "        const entry = canvases.get(command.c);\n",
  "        if (entry) entry.mouse = true;\n",
  "        break;\n",
  "      }\n",
  "      case \"on_pointer\": {\n",
  "        const entry = canvases.get(command.c);\n",
  "        if (entry) entry.pointer = true;\n",
  "        break;\n",
  "      }\n",
  "      case \"on_key\":\n",
  "        keysWanted = true;\n",
  "        // Inside another page the keys go where the focus is, which is\n",
  "        // still the Run button that started the program; one typing in\n",
  "        // an editor keeps it.\n",
  "        if (!standalone && !typing()) element.focus({ preventScroll: true });\n",
  "        break;\n",
  "    }\n",
  "  }\n",
  "\n",
  "  function typing() {\n",
  "    const active = document.activeElement;\n",
  "    return !!active && (active.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName));\n",
  "  }\n",
  "\n",
  "  function freeze() {\n",
  "    if (closed) return;\n",
  "    closed = true;\n",
  "    cancelAnimationFrame(frameRequest);\n",
  "    if (pacer !== 0) clearInterval(pacer);\n",
  "    if (splash !== null) {\n",
  "      window.removeEventListener(\"keydown\", dismissSplash, true);\n",
  "      splash.remove();\n",
  "    }\n",
  "    keyTarget.removeEventListener(\"keydown\", onKey);\n",
  "    keyTarget.removeEventListener(\"keyup\", onKeyUp);\n",
  "    window.removeEventListener(\"blur\", onBlur);\n",
  "    if (!standalone) element.removeEventListener(\"click\", takeFocus);\n",
  "    engine.close();\n",
  "    if (audio !== null && audio.state !== \"closed\") audio.close().catch(() => {});\n",
  "  }\n",
  "\n",
  "  return {\n",
  "    receive(commands) {\n",
  "      if (closed) return;\n",
  "      for (const command of commands) take(command);\n",
  "    },\n",
  "    setHidden,\n",
  "    // Stops: no more events, frames or sound, and what is shown stays.\n",
  "    freeze,\n",
  "    close() {\n",
  "      freeze();\n",
  "      box.remove();\n",
  "      unstyled(look);\n",
  "      if (focusable) {\n",
  "        element.removeAttribute(\"tabindex\");\n",
  "        element.blur();\n",
  "      }\n",
  "    },\n",
  "  };\n",
  "}\n",
].join("");
// END tinyweb page

// Where this file is the server's worker thread (see `Hub`), it serves.
if (!isMainThread && workerData?.tinywebServer) serveOnWorker(workerData);
